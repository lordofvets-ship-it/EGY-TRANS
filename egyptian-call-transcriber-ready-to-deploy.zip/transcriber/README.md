<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/47a718b4-8d16-4fdf-91e2-4b0401f39e6d

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`


## Production notes

- Audio is uploaded as `multipart/form-data`; the browser no longer converts the call to base64.
- `MAX_AUDIO_MB` controls the upload limit (default 25 MB).
- Keep `GEMINI_API_KEY`, `OPENAI_API_KEY`, `QWEN_CLEO_API_KEY`, and `HF_TOKEN` in the hosting provider's server-side secrets manager. Never put them in React/client code.
- Google AI Studio supports full-stack React + Node.js apps and can deploy them to Cloud Run; server-side secrets are kept out of client code.
