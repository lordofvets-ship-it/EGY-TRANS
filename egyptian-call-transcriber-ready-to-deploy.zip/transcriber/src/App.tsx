import React, { useState, useRef, useEffect } from "react";
import { 
  Upload, 
  Volume2, 
  Clock, 
  AlertCircle, 
  CheckCircle2, 
  Activity, 
  FileAudio, 
  RotateCcw, 
  User, 
  Headphones, 
  FileSpreadsheet,
  AlertTriangle,
  Play,
  Heart,
  Sparkles,
  PhoneOff,
  Award,
  Smile,
  MessageSquare,
  Music,
  VolumeX
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { TranscriptionResponse, TranscriptItem } from "./types";

export default function App() {
  const [file, setFile] = useState<File | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);
  const [result, setResult] = useState<TranscriptionResponse | null>(null);
  const [errorString, setErrorString] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [activeSegmentFilter, setActiveSegmentFilter] = useState<"all" | "silence" | "agent" | "customer">("all");
  const [engineStatus, setEngineStatus] = useState<{
    whisperApiAvailable?: boolean;
    qwenCleoAvailable?: boolean;
    qwenCleoMode?: string;
    engineName?: string;
  } | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    fetch("/api/engine-status")
      .then((res) => res.json())
      .then((data) => setEngineStatus(data))
      .catch(() => {});
  }, []);

  // Egypt Arabic Dialect call center status messages for visual feedback
  const progressSteps = [
    "جاري فحص الملف وتفعيل معالج QwenCleo-ASR و Whisper عالي الحساسية للعامية المصرية...",
    "جاري الإنصات للترددات الخافتة واستخراج أدق الأصوات وردود التأكيد المكتومة...",
    "جاري التفرقة الصوتية التامة (Speaker Diarization) بين صوت العميل والموظف...",
    "جاري تدقيق الترحيب، التعاطف، الهولد، صمت الموظف، واللازمات اللفظية..."
  ];

  useEffect(() => {
    if (isLoading) {
      const stepInterval = setInterval(() => {
        setLoadingStep((prev) => (prev < progressSteps.length - 1 ? prev + 1 : prev));
      }, 4000);
      return () => clearInterval(stepInterval);
    } else {
      setLoadingStep(0);
    }
  }, [isLoading]);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const droppedFile = e.dataTransfer.files[0];
      if (droppedFile.type.startsWith("audio/")) {
        selectAudioFile(droppedFile);
      } else {
        setErrorString("عذراً، يرجى تزويد ملف صوتي صالح فقط.");
      }
    }
  };

  const selectAudioFile = (selectedFile: File) => {
    setErrorString(null);
    setFile(selectedFile);
    const url = URL.createObjectURL(selectedFile);
    setAudioUrl(url);
    setResult(null); // Reset previous result
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      selectAudioFile(e.target.files[0]);
    }
  };

  // Upload the original audio as multipart/form-data. The server handles the binary file.
  const translateAndTranscribeAudio = async () => {
    if (!file) {
      setErrorString("يرجى اختيار ملف مكالمة صوتي أولاً.");
      return;
    }

    setIsLoading(true);
    setErrorString(null);

    try {
      const formData = new FormData();
      formData.append("audio", file, file.name);

      const response = await fetch("/api/transcribe", {
        method: "POST",
        body: formData,
      });

      const rawText = await response.text();
      let data: any = null;

      try {
        data = JSON.parse(rawText);
      } catch {
        throw new Error(`تعذر قراءة استجابة الخادم (${response.status}).`);
      }

      if (!response.ok) {
        throw new Error(data?.error || `فشل تفريغ المكالمة (${response.status}).`);
      }

      setResult(data);
    } catch (err: any) {
      console.error("Transcribe error:", err);
      let msg = err?.message || "فشل تفريغ وتحليل المكالمة.";
      if (msg.includes("Failed to fetch") || msg.includes("NetworkError") || msg.includes("Load failed")) {
        msg = "تعذر الاتصال بالخادم. تأكد من اتصال الإنترنت ثم أعد المحاولة.";
      }
      setErrorString(msg);
    } finally {
      setIsLoading(false);
    }
  };

  const resetAll = () => {
    setFile(null);
    setAudioUrl(null);
    setResult(null);
    setErrorString(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const toggleBenchmarkStatus = () => {
    if (!result) return;
    setResult((prev) => {
      if (!prev) return null;
      const nextIsBenchmark = !prev.isBenchmark;
      return {
        ...prev,
        isBenchmark: nextIsBenchmark,
        benchmarkNotes: nextIsBenchmark 
          ? "المكالمة المعيارية المعتمدة (BENCHMARK) لتدقيق الجودة - نبرة الصوت: ينقصها الابتسامة وبها تردد أحياناً."
          : undefined,
      };
    });
  };

  const filteredTranscript = result?.transcript.filter((item) => {
    if (activeSegmentFilter === "all") return true;
    const isSilence = item.speaker.includes("صمت") || item.speaker.includes("فترة صمت الموظف");
    const isAgent = item.speaker.includes("موظف") || item.speaker.includes("كول سنتر");
    const isCustomer = item.speaker.includes("عميل") || (!isSilence && !isAgent);

    if (activeSegmentFilter === "silence") return isSilence;
    if (activeSegmentFilter === "agent") return isAgent;
    if (activeSegmentFilter === "customer") return isCustomer;
    return true;
  });

  return (
    <div dir="rtl" className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col justify-between selection:bg-amber-500 selection:text-neutral-950">
      
      {/* Header Bar */}
      <header className="border-b border-neutral-900 bg-neutral-950/80 backdrop-blur-md sticky top-0 z-40 px-6 py-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-500/10 text-amber-500 rounded-xl border border-amber-500/20">
              <Headphones className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h1 id="app-title" className="text-lg font-bold tracking-tight text-white leading-tight">مُفرِّغ المكالمات ومُحلل صمت الزميل</h1>
              <p className="text-xs text-neutral-400 font-medium">مخصص للعامية المصرية ودعم مراقبة جودة الـ Call Center</p>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-2 font-mono text-xs text-neutral-500">
            <span>QA Portal</span>
            <span className="text-neutral-700">•</span>
            <span>v1.2.0</span>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-4 py-8">
        
        <AnimatePresence mode="wait">
          {!result && !isLoading && (
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              className="space-y-6"
            >
              <div className="bg-neutral-900/40 p-6 rounded-2xl border border-neutral-900/80 space-y-3">
                <div>
                  <h2 className="text-base font-semibold text-neutral-100 mb-1">تفريغ المحادثات وتحليل جودة المكالمة</h2>
                  <p className="text-neutral-400 text-sm leading-relaxed">
                    أنزل ملف تسجيل المكالمة (بأي صيغة مثل MP3، WAV، M4A) الخاص بزميل السنتر لتفريغ المكالمة بدقة متناهية وفصل أطراف الحديث وتحليل عناصر الجودة.
                  </p>
                </div>

                {/* Speech & Acoustic Engines Status */}
                <div className="pt-2 border-t border-neutral-800/60 flex flex-wrap items-center gap-2 text-xs">
                  <span className="text-neutral-400 font-medium">محركات التفريغ والذكاء الصوتي المدعومة:</span>
                  <span className="px-2.5 py-1 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 font-mono text-[11px] flex items-center gap-1.5 font-semibold" title="موديل QwenCleo-ASR المتخصص في العامية المصرية والتبديل اللغوي">
                    <Sparkles className="w-3 h-3 text-cyan-400" />
                    QwenCleo-ASR (العامية المصرية)
                    {engineStatus?.qwenCleoAvailable ? (
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" title="متصل ونشط" />
                    ) : (
                      <span className="text-[9px] px-1.5 py-0.2 bg-cyan-950 text-cyan-300 rounded border border-cyan-800/40">جاهز للربط</span>
                    )}
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono text-[11px] flex items-center gap-1.5 font-semibold">
                    <Activity className="w-3 h-3 text-emerald-400" />
                    Whisper-1 (OpenAI)
                    {engineStatus?.whisperApiAvailable && (
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    )}
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20 font-mono text-[11px] flex items-center gap-1.5 font-semibold">
                    <Headphones className="w-3 h-3 text-amber-400" />
                    Gemini Acoustic Diarization
                  </span>
                </div>
              </div>

              {/* Upload Panel */}
              <div 
                id="drag-and-drop-container"
                onDragEnter={handleDrag}
                onDragOver={handleDrag}
                onDragLeave={handleDrag}
                onDrop={handleDrop}
                className={`relative p-10 sm:p-12 rounded-2xl border-2 border-dashed flex flex-col items-center justify-center transition-all duration-300 min-h-[240px] ${
                  dragActive 
                    ? "border-amber-500 bg-amber-500/5 text-amber-400" 
                    : "border-neutral-800 bg-neutral-900/20 hover:border-neutral-700 text-neutral-400"
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="audio/*"
                  onChange={handleFileChange}
                  className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                  id="audio-uploader"
                />
                <div className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800 mb-4 flex items-center justify-center">
                  <Upload className={`w-10 h-10 transition-transform duration-300 ${dragActive ? "scale-110 text-amber-500" : "text-neutral-400"}`} />
                </div>
                <p className="text-base font-semibold text-neutral-200 text-center mb-1">اسحب وأفلت ملف تسجيل المكالمة الصوتي هنا</p>
                <p className="text-xs text-neutral-500 text-center mb-5">أو انقر في أي مكان لتصفح واختيار الملف من جهازك</p>
                <div className="flex flex-wrap items-center justify-center gap-2">
                  <span className="text-[11px] px-3 py-1 bg-neutral-900 text-neutral-400 rounded-full border border-neutral-800 font-mono">
                    WAV • MP3 • M4A • WEBM • OGG • AAC
                  </span>
                </div>
              </div>

              {/* Error Segment */}
              {errorString && (
                <motion.div 
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-4 bg-red-950/20 border border-red-900/50 rounded-xl text-red-400 text-xs flex items-start gap-3"
                >
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-semibold text-red-300">أخطأ ما حدث:</h3>
                    <p className="mt-1 leading-relaxed font-sans">{errorString}</p>
                  </div>
                </motion.div>
              )}

              {/* Ready File Area */}
              {file && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-neutral-900/60 border border-amber-500/10 rounded-2xl p-5 space-y-4"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-amber-500/15 rounded-xl text-amber-500">
                        <FileAudio className="w-6 h-6" />
                      </div>
                      <div className="space-y-0.5">
                        <h4 className="text-sm font-bold text-neutral-100 truncate max-w-xs sm:max-w-md">{file.name}</h4>
                        <p className="text-xs text-neutral-500 font-mono">{(file.size / (1024 * 1024)).toFixed(2)} ميجابايت • {file.type || "صيغة غير معروفة"}</p>
                      </div>
                    </div>
                    {audioUrl && (
                      <div className="w-full sm:w-auto flex items-center">
                        <audio src={audioUrl} controls className="w-full sm:w-[240px] h-9 custom-audio-player bg-transparent" />
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-2 pt-2 border-t border-neutral-800">
                    <button
                      id="start-process-btn"
                      onClick={translateAndTranscribeAudio}
                      className="flex-1 py-3 px-5 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-sm rounded-xl transition-all shadow-md flex items-center justify-center gap-2"
                    >
                      <Activity className="w-4 h-4" />
                      ابدأ التفريغ الصوتي واستخراج فترات الصمت الذكي
                    </button>
                    <button
                      id="reset-btn"
                      onClick={resetAll}
                      className="p-3 bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white rounded-xl border border-neutral-800 transition-all"
                      title="إعادة التعيين والتراجع"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>
                  </div>
                </motion.div>
              )}

            </motion.div>
          )}

          {/* Loading Animation Area */}
          {isLoading && (
            <motion.div
              key="loading-screen"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="py-16 flex flex-col items-center justify-center space-y-8"
            >
              <div className="relative w-20 h-20">
                <div className="absolute inset-0 rounded-full border-4 border-amber-500/20" />
                <div className="absolute inset-0 rounded-full border-4 border-t-amber-500 border-r-transparent animate-spin" />
                <div className="absolute inset-4 rounded-full border border-neutral-800 flex items-center justify-center bg-neutral-950">
                  <Volume2 className="w-5 h-5 text-amber-500 animate-pulse" />
                </div>
              </div>

              <div className="text-center space-y-3 max-w-md">
                <h3 className="text-base font-bold text-white">جاري تحليل المكالمة بدقة</h3>
                <p className="text-xs text-neutral-400 leading-normal min-h-[2.5rem] px-4 font-medium italic">
                  "{progressSteps[loadingStep]}"
                </p>
                <div className="w-40 h-1 bg-neutral-900 rounded-full mx-auto overflow-hidden">
                  <motion.div 
                    initial={{ x: "-100%" }}
                    animate={{ x: "100%" }}
                    transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
                    className="w-1/2 h-full bg-amber-500 rounded-full"
                  />
                </div>
              </div>
            </motion.div>
          )}

          {/* Transcript Results Presentation Segment */}
          {result && !isLoading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3 }}
              className="space-y-6"
            >
              {/* Benchmark Call Calibration Header Banner */}
              {result.isBenchmark && (
                <motion.div 
                  id="benchmark-call-banner"
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-amber-500/15 via-amber-500/10 to-neutral-950 border-2 border-amber-500/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-lg shadow-amber-500/5"
                >
                  <div className="flex items-start gap-3.5">
                    <div className="p-3 bg-amber-500 text-neutral-950 rounded-xl font-bold shadow-md shrink-0">
                      <Sparkles className="w-6 h-6 text-neutral-950" />
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-base font-black text-amber-300 font-sans">المكالمة المعيارية المعتمدة (BENCHMARK)</span>
                        <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-200 border border-amber-500/50 font-bold font-mono">
                          مرجع تدقيق الجودة القياسي
                        </span>
                      </div>
                      <p className="text-xs text-neutral-200 font-sans leading-relaxed">
                        {result.benchmarkNotes || "المكالمة المعيارية المعتمدة لتدقيق جودة خدمة العملاء - معايير النبرة المحدثة: ينقصها الابتسامة وبها تردد أحياناً."}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 self-stretch sm:self-auto justify-end">
                    <span className="text-xs px-3 py-1.5 bg-neutral-900/90 text-amber-400 border border-amber-500/30 rounded-xl font-bold font-mono flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
                      معايرة معتمدة
                    </span>
                  </div>
                </motion.div>
              )}

              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-neutral-900/30 p-4 rounded-xl border border-neutral-900/80">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-emerald-500/10 rounded-lg text-emerald-500">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">اكتمال تفريغ وتحليل المكالمة الصوتية</h3>
                    <p className="text-xs text-neutral-400">العامّية المصرية، الإنصات العميق للهمسات، والتفرقة بين المتحدثين</p>
                    {result._engineInfo && (
                      <div className="mt-1.5 flex flex-wrap items-center gap-1.5 text-[10px]">
                        <span className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 font-medium">
                          {result._engineInfo.engineName}
                        </span>
                        {result._engineInfo.qwenCleoUsed && (
                          <span className="px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 font-medium">
                            ✓ تفريغ QwenCleo-ASR الفائق للعامية المصرية
                          </span>
                        )}
                        {result._engineInfo.whisperApiUsed && (
                          <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-medium">
                            ✓ تفريغ Whisper-1
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
                  <button
                    id="toggle-benchmark-btn"
                    onClick={toggleBenchmarkStatus}
                    className={`py-2 px-3 border rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      result.isBenchmark
                        ? "bg-amber-500/20 text-amber-300 border-amber-500/40 hover:bg-amber-500/30"
                        : "bg-neutral-900 hover:bg-neutral-800 border-neutral-800 text-neutral-400 hover:text-white"
                    }`}
                    title={result.isBenchmark ? "إلغاء تعيين المكالمة كـ Benchmark" : "اعتماد هذه المكالمة كمعيار مرجعي (Benchmark)"}
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    {result.isBenchmark ? "معيار معتمد (Benchmark)" : "اعتماد كـ Benchmark"}
                  </button>
                  <button
                    id="start-new-btn"
                    onClick={resetAll}
                    className="py-2 px-4 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    تحليل مكالمة جديدة
                  </button>
                </div>
              </div>



              {/* Agent Silence Moments Summary (Simple, Ordered, Clean) */}
              {result.agentSilenceSummary && (
                <div id="silence-summary-section" className="p-5 rounded-2xl bg-neutral-900/20 border border-neutral-900/80 space-y-4">
                  <div className="flex items-center justify-between pb-2 border-b border-neutral-800/60 font-sans">
                    <div className="flex items-center gap-2">
                      <VolumeX className="w-5 h-5 text-rose-400 animate-pulse" />
                      <h3 className="text-sm font-bold text-white">لحظات الصمت (Dead Air)</h3>
                    </div>
                    <span className="text-[10px] px-2.5 py-0.5 bg-rose-500/10 text-rose-400 border border-rose-500/20 rounded-full font-medium flex items-center gap-1">
                      <VolumeX className="w-3 h-3" />
                      بين الزميل والعميل حصراً
                    </span>
                  </div>

                  {/* Quick Totals: Count, Total Duration, Ratio */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="p-3 bg-neutral-950/40 rounded-xl border border-neutral-900 flex items-center justify-between">
                      <span className="text-xs text-neutral-400 font-medium">عدد لحظات الصمت</span>
                      <span className="text-lg font-black text-white">
                        {result.agentSilenceSummary.silenceCount || 0} <span className="text-xs text-neutral-500 font-bold">مرات</span>
                      </span>
                    </div>

                    <div className="p-3 bg-neutral-950/40 rounded-xl border border-neutral-900 flex items-center justify-between">
                      <span className="text-xs text-neutral-400 font-medium">إجمالي مدة الصمت</span>
                      <span className="text-lg font-black text-rose-400">
                        {result.agentSilenceSummary.totalSilenceSeconds || 0} <span className="text-xs text-neutral-500 font-bold">ثانية</span>
                      </span>
                    </div>

                    <div className="p-3 bg-neutral-950/40 rounded-xl border border-neutral-900 flex items-center justify-between">
                      <span className="text-xs text-neutral-400 font-medium">الحالة الإجمالية</span>
                      <div>
                        {result.agentSilenceSummary.silenceCount > 0 ? (
                          <span className="text-xs px-2.5 py-1 bg-rose-500/10 text-rose-400 rounded-full border border-rose-500/25 font-bold">
                            رُصد صمت ({result.agentSilenceSummary.silenceRatio || 0}%)
                          </span>
                        ) : (
                          <span className="text-xs px-2.5 py-1 bg-emerald-500/10 text-emerald-400 rounded-full border border-emerald-500/25 font-bold">
                            لا يوجد صمت
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Simple Ordered List of Silence Moments */}
                  {result.agentSilenceSummary.silenceSegments && result.agentSilenceSummary.silenceSegments.length > 0 ? (
                    <div className="pt-1 space-y-2">
                      <span className="text-xs text-neutral-400 font-bold">جدول لحظات الصمت مرتبة زمنياً:</span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                        {result.agentSilenceSummary.silenceSegments.map((seg, idx) => (
                          <div
                            key={idx}
                            className="p-3 bg-neutral-950/60 rounded-xl border border-neutral-900 flex items-center justify-between text-xs"
                          >
                            <div className="flex items-center gap-2">
                              <span className="flex items-center justify-center w-5 h-5 rounded-full bg-rose-500/10 text-rose-400 text-[10px] font-bold border border-rose-500/20">
                                {idx + 1}
                              </span>
                              <div className="font-mono text-neutral-300 font-semibold flex items-center gap-1">
                                <Clock className="w-3.5 h-3.5 text-rose-400/80" />
                                <span>{seg.timeStart}</span>
                                <span className="text-neutral-600">←</span>
                                <span>{seg.timeEnd}</span>
                              </div>
                            </div>
                            <span className="text-xs font-bold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20">
                              {seg.duration} ث
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="p-3 bg-neutral-950/40 rounded-xl border border-neutral-900 text-xs text-neutral-400 text-center">
                      لم يتم رصد أي فترات صمت ملحوظة في هذه المكالمة.
                    </div>
                  )}
                </div>
              )}

              {/* Customer Name Analysis Widget */}
              {result.customerNameAnalysis && (
                <div className="p-5 rounded-2xl bg-neutral-900/20 border border-neutral-900/80 space-y-4">
                  <div className="flex items-center gap-2 pb-2 border-b border-neutral-800/60">
                    <User className="w-5 h-5 text-amber-500" />
                    <h3 className="text-sm font-bold text-white">تدقيق ومراقبة ذكر اسم العميل</h3>
                    <span className="text-[10px] px-2 py-0.5 bg-amber-500/10 text-amber-500 border border-amber-500/20 rounded font-medium">طلب تحديث</span>
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {/* Customer Name Detected */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900 flex flex-col justify-between">
                      <span className="text-xs text-neutral-400 font-medium">الاسم المكتشف للعميل</span>
                      <span className="text-lg font-extrabold text-amber-100 mt-2">
                        {result.customerNameAnalysis.customerNameDetected || "لم يذكر"}
                      </span>
                    </div>

                    {/* Mentions Status */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900 flex flex-col justify-between">
                      <span className="text-xs text-neutral-400 font-medium font-sans">هل ذكر الزميل اسم العميل؟</span>
                      <div className="mt-2 flex items-center">
                        {result.customerNameAnalysis.isMentionedByAgent ? (
                          <span className="text-xs px-2.5 py-1 bg-emerald-500/10 text-emerald-400 rounded-full border border-emerald-500/25 font-bold flex items-center gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            نعم، نادى على العميل باسمه
                          </span>
                        ) : (
                          <span className="text-xs px-2.5 py-1 bg-red-500/10 text-red-400 rounded-full border border-red-500/25 font-bold flex items-center gap-1.5">
                            <AlertCircle className="w-3.5 h-3.5" />
                            لا، لم ينادِ العميل باسمه
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Commits Count */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-950 flex flex-col justify-between">
                      <span className="text-xs text-neutral-400 font-medium">عدد مرات ذكر الاسم</span>
                      <div className="mt-2 flex items-center justify-between gap-2">
                        <span className="text-2xl font-black text-white leading-none">
                          {result.customerNameAnalysis.mentionCount} <span className="text-xs text-neutral-500 font-bold">مرات</span>
                        </span>
                        {result.customerNameAnalysis.mentionsTimestamps && result.customerNameAnalysis.mentionsTimestamps.length > 0 && (
                          <div className="flex flex-wrap gap-1 max-w-[140px] justify-end">
                            {result.customerNameAnalysis.mentionsTimestamps.map((ts, idx) => (
                              <span key={idx} className="text-[10px] font-mono bg-neutral-900 text-neutral-400 border border-neutral-800 px-1.5 py-0.5 rounded-md font-bold">
                                {ts}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Customer Title Analysis Widget */}
              {result.customerTitleAnalysis && (
                <div className="p-5 rounded-2xl bg-neutral-900/20 border border-neutral-900/80 space-y-4 animate-fade-in animate-duration-300">
                  <div className="flex items-center gap-2 pb-2 border-b border-neutral-800/60 font-sans">
                    <Award className="w-5 h-5 text-purple-500 animate-pulse" />
                    <h3 className="text-sm font-bold text-white">تدقيق ومراقبة استخدام ألقاب العميل الموقرة</h3>
                    <span className="text-[10px] px-2 py-0.5 bg-purple-500/10 text-purple-400 border border-purple-500/20 rounded font-medium">ألقاب العميل المهنية</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {/* Customer Title Detected */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900 flex flex-col justify-between">
                      <span className="text-xs text-neutral-400 font-medium font-sans">اللقب الفني/التشريفي الفعلي المكتشف للعميل</span>
                      <div className="mt-2">
                        {result.customerTitleAnalysis.titleDetected && result.customerTitleAnalysis.titleDetected !== "لم يذكر" ? (
                          <span className="text-base font-extrabold text-purple-300 bg-purple-500/10 border border-purple-500/20 px-3 py-1 rounded-lg">
                            {result.customerTitleAnalysis.titleDetected}
                          </span>
                        ) : (
                          <span className="text-xs text-neutral-500 italic font-medium">لم يتم كشف لقب مهني خاص</span>
                        )}
                      </div>
                    </div>

                    {/* Did Agent Use Title */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900 flex flex-col justify-between">
                      <span className="text-xs text-neutral-400 font-medium font-sans">مدى التزام الزميل بمناداة اللقب</span>
                      <div className="mt-2 flex items-center">
                        {result.customerTitleAnalysis.isTitleUsedByAgent ? (
                          <span className="text-xs px-2.5 py-1 bg-emerald-500/10 text-emerald-400 rounded-full border border-emerald-500/25 font-bold flex items-center gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                            نعم، التزم بلقب العميل الوقور
                          </span>
                        ) : (
                          <span className="text-xs px-2.5 py-1 bg-zinc-500/10 text-neutral-400 rounded-full border border-zinc-500/25 font-bold flex items-center gap-1.5">
                            <AlertCircle className="w-3.5 h-3.5 text-neutral-400" />
                            لم يستعمل لقب مهني أو لا يوجد لقب
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Title Mentions Count */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900 flex flex-col justify-between">
                      <span className="text-xs text-neutral-400 font-medium">عدد مرات ذكر اللقب</span>
                      <div className="mt-2 flex items-center justify-between gap-2">
                        <span className="text-2xl font-black text-white leading-none">
                          {result.customerTitleAnalysis.titleMentionCount || 0} <span className="text-xs text-neutral-500 font-bold font-sans">مرات</span>
                        </span>
                        {result.customerTitleAnalysis.titleMentionsTimestamps && result.customerTitleAnalysis.titleMentionsTimestamps.length > 0 && (
                          <div className="flex flex-wrap gap-1 max-w-[140px] justify-end">
                            {result.customerTitleAnalysis.titleMentionsTimestamps.map((ts, idx) => (
                              <span key={idx} className="text-[10px] font-mono bg-purple-950/50 text-purple-300 border border-purple-900 px-1.5 py-0.5 rounded shadow-sm font-bold">
                                {ts}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Title text snippet */}
                  {result.customerTitleAnalysis.titleTextSnippet && result.customerTitleAnalysis.titleTextSnippet !== "" && (
                    <div className="p-4 bg-neutral-950/60 rounded-xl border border-neutral-900 space-y-1.5">
                      <span className="text-xs text-neutral-400 font-medium font-sans">النص الملتقط لنداء اللقب:</span>
                      <p className="text-sm font-semibold text-neutral-200 italic leading-relaxed">
                        " {result.customerTitleAnalysis.titleTextSnippet} "
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* Agent Apology Analysis Widget */}
              {result.agentApologyAnalysis && (
                <div className="p-5 rounded-2xl bg-neutral-900/20 border border-neutral-900/80 space-y-4 animate-fade-in animate-duration-300">
                  <div className="flex items-center gap-2 pb-2 border-b border-neutral-800/60 font-sans">
                    <Activity className="w-5 h-5 text-amber-500 animate-pulse" />
                    <h3 className="text-sm font-bold text-white">تدقيق ومراقبة اعتذار الزميل عن المشاكل</h3>
                    <span className="text-[10px] px-2 py-0.5 bg-amber-500/10 text-amber-500 border border-amber-500/20 rounded font-medium">مراقبة الاعتذار</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {/* Did context require apology */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900 flex flex-col justify-between">
                      <span className="text-xs text-neutral-400 font-medium font-sans">هل الموقف يتطلب اعتذاراً؟</span>
                      <div className="mt-2">
                        {result.agentApologyAnalysis.isApologyNeeded ? (
                          <span className="text-xs px-2.5 py-1 bg-amber-500/10 text-amber-450 rounded-full border border-amber-500/25 font-bold flex items-center gap-1.5 w-fit">
                            <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
                            نعم، يتطلب اعتذاراً
                          </span>
                        ) : (
                          <span className="text-xs px-2.5 py-1 bg-emerald-500/10 text-emerald-400 rounded-full border border-emerald-500/25 font-bold flex items-center gap-1.5 w-fit">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            لا، لا يوجد مبرر للاعتذار
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Did Agent Apologize */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900 flex flex-col justify-between">
                      <span className="text-xs text-neutral-400 font-medium font-sans font-bold">هل قدم الزميل اعتذاراً صريحاً؟</span>
                      <div className="mt-2 text-xs">
                        {result.agentApologyAnalysis.isApologyUsedByAgent ? (
                          <span className="px-2.5 py-1 bg-emerald-500/10 text-emerald-400 rounded-full border border-emerald-500/25 font-bold flex items-center gap-1.5 w-fit">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                            نعم، بادر بالاعتذار
                          </span>
                        ) : result.agentApologyAnalysis.isApologyNeeded ? (
                          <span className="px-2.5 py-1 bg-rose-500/10 text-rose-400 rounded-full border border-rose-500/25 font-bold flex items-center gap-1.5 w-fit">
                            <AlertTriangle className="w-3.5 h-3.5 text-rose-400 animate-bounce" />
                            عجز: لم يعتذر الموظف!
                          </span>
                        ) : (
                          <span className="text-neutral-500 italic font-medium">لم يعتذر (ولم يكن مطلوباً)</span>
                        )}
                      </div>
                    </div>

                    {/* Apology Mentions Count & Timestamps */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900 flex flex-col justify-between">
                      <span className="text-xs text-neutral-400 font-medium">عدد مرات تقديم الاعتذار</span>
                      <div className="mt-2 flex items-center justify-between gap-2">
                        <span className="text-2xl font-black text-white leading-none">
                          {result.agentApologyAnalysis.apologyMentionCount || 0} <span className="text-xs text-neutral-500 font-bold font-sans">مرات</span>
                        </span>
                        {result.agentApologyAnalysis.apologyTimestamps && result.agentApologyAnalysis.apologyTimestamps.length > 0 && (
                          <div className="flex flex-wrap gap-1 max-w-[140px] justify-end">
                            {result.agentApologyAnalysis.apologyTimestamps.map((ts, idx) => (
                              <span key={idx} className="text-[10px] font-mono bg-amber-950/50 text-amber-300 border border-amber-900 px-1.5 py-0.5 rounded font-bold">
                                {ts}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Apology text snippet */}
                  {result.agentApologyAnalysis.apologyTextSnippet && result.agentApologyAnalysis.apologyTextSnippet !== "" && (
                    <div className="p-4 bg-neutral-950/60 rounded-xl border border-neutral-900 space-y-1.5 animate-fade-in">
                      <span className="text-xs text-neutral-400 font-medium font-sans">نص الاعتذار المسموع في المكالمة:</span>
                      <p className="text-sm font-semibold text-neutral-200 italic leading-relaxed">
                        " {result.agentApologyAnalysis.apologyTextSnippet} "
                      </p>
                    </div>
                  )}

                  {/* Apology evaluation comment */}
                  {result.agentApologyAnalysis.evaluation && (
                    <div className="p-4 bg-amber-500/5 rounded-xl border border-amber-500/10 space-y-1">
                      <span className="text-xs text-amber-500 font-bold font-sans">التقييم الفني لمرونة الموظف ولباقة اعتذاره:</span>
                      <p className="text-sm text-neutral-200 leading-relaxed font-sans font-medium">
                        {result.agentApologyAnalysis.evaluation}
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* Review and Audit of Greeting GreetingAnalysis Widget */}
              {result.greetingAnalysis && (
                <div className="p-5 rounded-2xl bg-neutral-900/20 border border-neutral-900/80 space-y-4 animate-fade-in">
                  <div className="flex items-center gap-2 pb-2 border-b border-neutral-800/60 font-sans">
                    <Headphones className="w-5 h-5 text-amber-500 animate-pulse" />
                    <h3 className="text-sm font-bold text-white">مراجعة وتدقيق ترحيب مقدمة المكالمة</h3>
                    <span className="text-[10px] px-2 py-0.5 bg-amber-500/10 text-amber-500 border border-amber-500/20 rounded font-medium">تدقيق ترحيب المقدمة</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {/* Greeting used status */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900 flex flex-col justify-between">
                      <span className="text-xs text-neutral-400 font-medium font-sans">حالة عبارات الترحيب (أهلاً وسهلاً / نورتنا / شرفتنا)</span>
                      <div className="mt-2 flex items-center">
                        {result.greetingAnalysis.isGreetingUsed ? (
                          <span className="text-xs px-2.5 py-1 bg-emerald-500/10 text-emerald-400 rounded-full border border-emerald-500/25 font-bold flex items-center gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                            تم استخدام عبارات الترحيب بامتياز
                          </span>
                        ) : (
                          <span className="text-xs px-2.5 py-1 bg-rose-500/10 text-rose-400 rounded-full border border-rose-500/25 font-bold flex items-center gap-1.5">
                            <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
                            لم يتم الترحيب
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Detected Greeting Phrases */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900 flex flex-col justify-between">
                      <span className="text-xs text-neutral-400 font-medium font-sans font-bold">عبارات الترحيب المكتشفة في البداية</span>
                      <div className="mt-2 flex flex-wrap gap-1.5">
                        {result.greetingAnalysis.detectedGreetingPhrases && result.greetingAnalysis.detectedGreetingPhrases.length > 0 ? (
                          result.greetingAnalysis.detectedGreetingPhrases.map((phrase, idx) => (
                            <span key={idx} className="text-xs font-bold bg-amber-500/10 text-amber-300 border border-amber-500/20 px-2.5 py-1 rounded-lg">
                              {phrase}
                            </span>
                          ))
                        ) : (
                          <span className="text-xs text-neutral-500 font-medium">لم تُكتشف مفردات ترحيب</span>
                        )}
                      </div>
                    </div>

                    {/* Greeting Timestamps */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900 flex flex-col justify-between">
                      <span className="text-xs text-neutral-400 font-medium font-sans font-bold">وقت ذكر عبارة الترحيب</span>
                      <div className="mt-2 flex flex-wrap gap-1">
                        {result.greetingAnalysis.greetingTimestamps && result.greetingAnalysis.greetingTimestamps.length > 0 ? (
                          result.greetingAnalysis.greetingTimestamps.map((ts, idx) => (
                            <span key={idx} className="text-xs font-mono font-bold bg-amber-950/50 text-amber-300 border border-amber-900/60 px-2.5 py-1 rounded-lg">
                              {ts}
                            </span>
                          ))
                        ) : (
                          <span className="text-xs text-neutral-500 font-medium italic">لم تُسجل طوابع ترحيب</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Greeting Text Snippet */}
                  {result.greetingAnalysis.greetingTextSnippet && (
                    <div className="p-4 bg-neutral-950/60 rounded-xl border border-neutral-900 space-y-1.5">
                      <span className="text-xs text-neutral-400 font-medium">النص الملتقط للترحيب بالمقدمة:</span>
                      <p className="text-sm font-semibold text-neutral-200 italic leading-relaxed">
                        " {result.greetingAnalysis.greetingTextSnippet} "
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* Empathy Analysis Widget */}
              {result.empathyAnalysis && (
                <div className="p-5 rounded-2xl bg-neutral-900/20 border border-neutral-900/80 space-y-4 animate-fade-in animate-duration-300">
                  <div className="flex items-center gap-2 pb-2 border-b border-neutral-800/60 font-sans">
                    <Heart className="w-5 h-5 text-rose-500 animate-pulse" />
                    <h3 className="text-sm font-bold text-white">مراجعة وتدقيق تعاطف الزميل</h3>
                    <span className="text-[10px] px-2 py-0.5 bg-rose-500/10 text-rose-400 border border-rose-500/20 rounded font-medium">تدقيق التعاطف</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {/* Empathy indicator */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900 flex flex-col justify-between">
                      <span className="text-xs text-neutral-400 font-medium">حالة التعاطف (بالشفاء / ألف سلامة)</span>
                      <div className="mt-2 flex items-center">
                        {result.empathyAnalysis.isEmpathyUsed ? (
                          <span className="text-xs px-2.5 py-1 bg-emerald-500/10 text-emerald-400 rounded-full border border-emerald-500/25 font-bold flex items-center gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                            تم التعاطف بعبارات مخصصة
                          </span>
                        ) : (
                          <span className="text-xs px-2.5 py-1 bg-rose-500/10 text-rose-450 rounded-full border border-rose-500/25 font-bold flex items-center gap-1.5">
                            <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
                            لم يتم التعاطف
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Detected empathy words */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900 flex flex-col justify-between">
                      <span className="text-xs text-neutral-400 font-medium font-sans font-bold">عبارات التعاطف المكتشفة</span>
                      <div className="mt-2 flex flex-wrap gap-1.5">
                        {result.empathyAnalysis.detectedEmpathyPhrases && result.empathyAnalysis.detectedEmpathyPhrases.length > 0 ? (
                          result.empathyAnalysis.detectedEmpathyPhrases.map((phrase, idx) => (
                            <span key={idx} className="text-xs font-bold bg-rose-500/10 text-rose-300 border border-rose-500/20 px-2.5 py-1 rounded-lg animate-fade-in">
                              {phrase}
                            </span>
                          ))
                        ) : (
                          <span className="text-xs text-neutral-500 font-medium">لم تُكتشف عبارات تعاطف مخصصة</span>
                        )}
                      </div>
                    </div>

                    {/* Empathy Mentions Count & Timestamps */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900 flex flex-col justify-between">
                      <span className="text-xs text-neutral-400 font-medium font-sans">عدد مرات ذكر التعاطف وأوقاته</span>
                      <div className="mt-2 flex items-center justify-between gap-2">
                        <span className="text-2xl font-black text-white leading-none">
                          {result.empathyAnalysis.empathyCount || 0} <span className="text-xs text-neutral-500 font-bold font-sans">مرات</span>
                        </span>
                        {result.empathyAnalysis.empathyTimestamps && result.empathyAnalysis.empathyTimestamps.length > 0 && (
                          <div className="flex flex-wrap gap-1 max-w-[140px] justify-end">
                            {result.empathyAnalysis.empathyTimestamps.map((ts, idx) => (
                              <span key={idx} className="text-[10px] font-mono bg-rose-950/50 text-rose-300 border border-rose-900 px-1.5 py-0.5 rounded font-bold shadow-sm">
                                {ts}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Empathy Snippet text */}
                  {result.empathyAnalysis.empathyTextSnippet && (
                    <div className="p-4 bg-neutral-950/60 rounded-xl border border-neutral-900 space-y-1.5 animate-fade-in">
                      <span className="text-xs text-neutral-400 font-medium">النص الملتقط للتعاطف مع العميل:</span>
                      <p className="text-sm font-semibold text-neutral-200 italic leading-relaxed">
                        " {result.empathyAnalysis.empathyTextSnippet} "
                      </p>
                    </div>
                  )}

                  {/* Empathy evaluation comments */}
                  {result.empathyAnalysis.evaluation && (
                    <div className="p-4 bg-rose-500/5 rounded-xl border border-rose-500/10 space-y-1">
                      <span className="text-xs text-rose-400 font-bold">التقييم الفني لجودة المراعاة والتعاطف:</span>
                      <p className="text-sm text-neutral-200 leading-relaxed font-sans">
                        {result.empathyAnalysis.evaluation}
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* Offering Other Services / Further Assistance Audit Widget */}
              {result.furtherAssistanceAnalysis && (
                <div className="p-5 rounded-2xl bg-neutral-900/20 border border-neutral-900/80 space-y-4 animate-fade-in animate-duration-300">
                  <div className="flex items-center gap-2 pb-2 border-b border-neutral-800/60 font-sans flex-wrap justify-between">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-amber-500 animate-pulse" />
                      <h3 className="text-sm font-bold text-white">مراجعة وتدقيق عرض الخدمات والمساعدة الإضافية قبل الإنهاء</h3>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 bg-amber-500/10 text-amber-500 border border-amber-500/20 rounded font-bold">
                      بعد مراجعة الطلب أو ذكر الإجمالي
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Assistance offered status */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900 flex flex-col justify-between space-y-2">
                      <span className="text-xs text-neutral-400 font-medium font-sans">حالة تقديم خدمات إضافية (مساعدة أخرى / إضافة شيء آخر)</span>
                      <div className="flex items-center">
                        {result.furtherAssistanceAnalysis.isAssistanceOffered ? (
                          <span className="text-xs px-2.5 py-1 bg-emerald-500/10 text-emerald-400 rounded-full border border-emerald-500/25 font-bold flex items-center gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                            تم عرض خدمات أخرى بالموضع المناسب
                          </span>
                        ) : (
                          <span className="text-xs px-2.5 py-1 bg-rose-500/10 text-rose-400 rounded-full border border-rose-500/25 font-bold flex items-center gap-1.5">
                            <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
                            لم يتم عرض خدمات أخرى بعد المراجعة/الإجمالي
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Detected Assistance Phrases */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900 flex flex-col justify-between">
                      <span className="text-xs text-neutral-400 font-medium font-sans font-bold">عبارات العرض المكتشفة</span>
                      <div className="mt-2 flex flex-wrap gap-1.5">
                        {result.furtherAssistanceAnalysis.detectedAssistancePhrases && result.furtherAssistanceAnalysis.detectedAssistancePhrases.length > 0 ? (
                          result.furtherAssistanceAnalysis.detectedAssistancePhrases.map((phrase, idx) => (
                            <span key={idx} className="text-xs font-bold bg-amber-500/10 text-amber-300 border border-amber-500/20 px-2.5 py-1 rounded-lg animate-fade-in">
                              {phrase}
                            </span>
                          ))
                        ) : (
                          <span className="text-xs text-neutral-500 font-medium">لم يتم كشف عبارات للمساعدة الإضافية</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Assistance text snippet */}
                  {result.furtherAssistanceAnalysis.assistanceTextSnippet && (
                    <div className="p-4 bg-neutral-950/60 rounded-xl border border-neutral-900 space-y-1.5 animate-fade-in">
                      <span className="text-xs text-neutral-400 font-medium font-sans">النص الملتقط لعرض الخدمات والمساعدة الأخرى:</span>
                      <p className="text-sm font-semibold text-neutral-200 italic leading-relaxed">
                        " {result.furtherAssistanceAnalysis.assistanceTextSnippet} "
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* Call Ending / Closing Phrase Audit Widget */}
              {result.callEndingAnalysis && (
                <div className="p-5 rounded-2xl bg-neutral-900/20 border border-neutral-900/80 space-y-4 animate-fade-in animate-duration-300">
                  <div className="flex items-center gap-2 pb-2 border-b border-neutral-800/60 font-sans">
                    <PhoneOff className="w-5 h-5 text-indigo-500 animate-pulse" />
                    <h3 className="text-sm font-bold text-white">مراجعة وتدقيق إنهاء ووداع المكالمة</h3>
                    <span className="text-[10px] px-2 py-0.5 bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 rounded font-medium">تدقيق الخاتمة</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Closing status */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900 flex flex-col justify-between">
                      <span className="text-xs text-neutral-400 font-medium font-sans">حالة قول عبارة الوداع الرسمية عند الإنهاء</span>
                      <div className="mt-2 flex items-center">
                        {result.callEndingAnalysis.isEndingPhraseUsed ? (
                          <span className="text-xs px-2.5 py-1 bg-emerald-500/10 text-emerald-400 rounded-full border border-emerald-500/25 font-bold flex items-center gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                            تم إنهاء المكالمة بالصيغة المطلوبة
                          </span>
                        ) : (
                          <span className="text-xs px-2.5 py-1 bg-rose-500/10 text-rose-400 rounded-full border border-rose-500/25 font-bold flex items-center gap-1.5">
                            <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
                            لم يتم الإنهاء بالصيغة المطلوبة
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Detected ending phrases list */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900 flex flex-col justify-between">
                      <span className="text-xs text-neutral-400 font-medium font-sans font-bold">عبارة الوداع المكتشفة مع العميل</span>
                      <div className="mt-2 flex flex-wrap gap-1.5">
                        {result.callEndingAnalysis.detectedEndingPhrases && result.callEndingAnalysis.detectedEndingPhrases.length > 0 ? (
                          result.callEndingAnalysis.detectedEndingPhrases.map((phrase, idx) => (
                            <span key={idx} className="text-xs font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 px-2.5 py-1 rounded-lg animate-fade-in">
                              {phrase}
                            </span>
                          ))
                        ) : (
                          <span className="text-xs text-neutral-500 font-medium italic">لم تُكتشف (شرفتنا، شرفت، أو شكرا لاتصالك)</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Ending segment text snippet */}
                  {result.callEndingAnalysis.endingTextSnippet && (
                    <div className="p-4 bg-neutral-950/60 rounded-xl border border-neutral-900 space-y-1.5 animate-fade-in">
                      <span className="text-xs text-neutral-400 font-medium font-sans">النص الملتقط لوداع الزميل بالخاتمة:</span>
                      <p className="text-sm font-semibold text-neutral-200 italic leading-relaxed">
                        " {result.callEndingAnalysis.endingTextSnippet} "
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* Unprofessional Words Analysis Widget */}
              {result.unprofessionalWordsAnalysis && (
                <div className="p-5 rounded-2xl bg-neutral-900/20 border border-neutral-900/80 space-y-4 animate-fade-in animate-duration-300">
                  <div className="flex items-center gap-2 pb-2 border-b border-neutral-800/60 font-sans">
                    <AlertTriangle className="w-5 h-5 text-amber-500 animate-pulse" />
                    <h3 className="text-sm font-bold text-white">تحليل ورصد الكلمات والألفاظ غير الاحترافية</h3>
                    <span className="text-[10px] px-2 py-0.5 bg-amber-500/10 text-amber-400 border border-amber-500/20 rounded font-medium">الألفاظ غير الاحترافية</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Status widget */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900 flex flex-col justify-between">
                      <span className="text-xs text-neutral-400 font-medium">حالة استخدام الألفاظ غير الاحترافية</span>
                      <div className="mt-2 flex items-center">
                        {result.unprofessionalWordsAnalysis.hasUnprofessionalWords ? (
                          <span className="text-xs px-2.5 py-1 bg-rose-500/10 text-rose-400 rounded-full border border-rose-500/25 font-bold flex items-center gap-1.5">
                            <AlertCircle className="w-3.5 h-3.5 text-rose-400 animate-bounce" />
                            تم رصد ألفاظ غير احترافية من الزميل ({result.unprofessionalWordsAnalysis.totalUnprofessionalWordsCount})
                          </span>
                        ) : (
                          <span className="text-xs px-2.5 py-1 bg-emerald-500/10 text-emerald-400 rounded-full border border-emerald-500/25 font-bold flex items-center gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                            أداء ممتاز: لم يتم رصد أي كلمة غير احترافية!
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Total unprofessional words count summary */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900 flex flex-col justify-between">
                      <span className="text-xs text-neutral-400 font-medium font-sans">العدد الإجمالي للكلمات المستخرجة للزميل</span>
                      <span className="text-lg font-extrabold text-white mt-2">
                        {result.unprofessionalWordsAnalysis.totalUnprofessionalWordsCount} <span className="text-xs text-neutral-500 font-medium font-sans">كلمة/كلمات</span>
                      </span>
                    </div>
                  </div>

                  {/* Words list details if any word is detected */}
                  {result.unprofessionalWordsAnalysis.detectedWords && result.unprofessionalWordsAnalysis.detectedWords.length > 0 && (
                    <div className="pt-2">
                      <h4 className="text-xs font-bold text-neutral-400 mb-2 font-sans">قائمة وتكرار الألفاظ غير الاحترافية التي تم رصدها صراحة:</h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {result.unprofessionalWordsAnalysis.detectedWords.map((item, idx) => (
                          <div key={idx} className="p-2.5 bg-neutral-950/60 rounded-lg border border-neutral-900 flex flex-col gap-2 text-xs">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                                <span className="text-neutral-200 font-bold font-sans">الكلمة: "{item.word}"</span>
                              </div>
                              <span className="text-xs px-2 py-0.5 bg-rose-500/10 text-rose-400 rounded-md font-bold">
                                تكررت {item.count} {item.count === 1 ? "مرة" : "مرات"}
                              </span>
                            </div>
                            {item.timestamps && item.timestamps.length > 0 && (
                              <div className="flex items-center gap-1 flex-wrap mt-1">
                                <span className="text-[10px] text-neutral-500 font-semibold font-sans">الطوابع الزمنية:</span>
                                {item.timestamps.map((time, tIdx) => (
                                  <span key={tIdx} className="text-[10px] font-mono bg-neutral-900 text-neutral-400 border border-neutral-800 px-1.5 py-0.5 rounded font-bold">
                                    {time}
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Evaluation & guidance feedback */}
                  {result.unprofessionalWordsAnalysis.evaluation && (
                    <div className="p-4 bg-rose-500/5 rounded-xl border border-rose-500/10 space-y-1">
                      <span className="text-xs text-rose-400 font-bold font-sans">التقييم الفني لأسلوب الحوار والبدائل المهنية:</span>
                      <p className="text-sm text-neutral-200 leading-relaxed font-sans">
                        {result.unprofessionalWordsAnalysis.evaluation}
                      </p>
                    </div>
                  )}
                </div>
              )}
              
              {/* Verbal Tics/Repeated Words Analysis Widget */}
              {result.verbalTicsAnalysis && (
                <div id="verbal-tics-analysis-section" className="p-5 rounded-2xl bg-neutral-900/20 border border-neutral-900/80 space-y-4 animate-fade-in animate-duration-300">
                  <div className="flex items-center gap-2 pb-2 border-b border-neutral-800/60 font-sans">
                    <MessageSquare className="w-5 h-5 text-indigo-400 animate-pulse" />
                    <h3 className="text-sm font-bold text-white font-sans">تحليل وتدقيق اللازمات اللفظية وتكرار الكلمات المتكرر</h3>
                    <span className="text-[10px] px-2 py-0.5 bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 rounded font-medium">اللازمات الحوارية</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Verbal Tics Status */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900 flex flex-col justify-between">
                      <span className="text-xs text-neutral-400 font-medium">حالة رصد اللازمات المتكررة</span>
                      <div className="mt-2 flex items-center">
                        {result.verbalTicsAnalysis.hasVerbalTics && result.verbalTicsAnalysis.detectedTics && result.verbalTicsAnalysis.detectedTics.length > 0 ? (
                          <span className="text-xs px-2.5 py-1 bg-amber-500/10 text-amber-400 rounded-full border border-amber-500/25 font-bold flex items-center gap-1.5">
                            <AlertTriangle className="w-3.5 h-3.5 text-amber-550 animate-bounce" />
                            تم رصد كثرة تكرار لبعض الكلمات ({result.verbalTicsAnalysis.detectedTics.length})
                          </span>
                        ) : (
                          <span className="text-xs px-2.5 py-1 bg-emerald-500/10 text-emerald-400 rounded-full border border-emerald-500/25 font-bold flex items-center gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                            تنوع لفظي ممتاز: لم يتم رصد أي كلمات متكررة كلازمات!
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Tics Count Summary */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900 flex flex-col justify-between">
                      <span className="text-xs text-neutral-400 font-medium font-sans">العدد الإجمالي للازمات الملحوظ تكرارها</span>
                      <span className="text-lg font-extrabold text-white mt-2">
                        {result.verbalTicsAnalysis.detectedTics ? result.verbalTicsAnalysis.detectedTics.length : 0} <span className="text-xs text-neutral-500 font-medium font-sans">لازمة لفظية</span>
                      </span>
                    </div>
                  </div>

                  {/* Verbal Tics List Details */}
                  {result.verbalTicsAnalysis.detectedTics && result.verbalTicsAnalysis.detectedTics.length > 0 && (
                    <div className="pt-2">
                      <h4 className="text-xs font-bold text-neutral-400 mb-2 font-sans">تفاصيل الكلمات المكررة كـ لقمة حوارية أو لازمة بحديث الزميل:</h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {result.verbalTicsAnalysis.detectedTics.map((item, idx) => (
                          <div key={idx} className="p-2.5 bg-neutral-950/60 rounded-lg border border-neutral-900 flex flex-col gap-2 text-xs">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
                                <span className="text-neutral-200 font-bold font-sans">اللازمة: "{item.word}"</span>
                              </div>
                              <span className="text-xs px-2 py-0.5 bg-indigo-500/10 text-indigo-400 rounded-md font-bold">
                                تكررت {item.count} {item.count === 1 ? "مرة" : "مرات"}
                              </span>
                            </div>
                            {item.timestamps && item.timestamps.length > 0 && (
                              <div className="flex items-center gap-1 flex-wrap mt-1">
                                <span className="text-[10px] text-neutral-500 font-semibold font-sans font-bold">طوابع تكرار اللفظ:</span>
                                <div className="flex flex-wrap gap-1">
                                  {item.timestamps.map((time, tIdx) => (
                                    <span key={tIdx} className="text-[10px] font-mono bg-neutral-900 text-neutral-300 border border-neutral-800 px-1.5 py-0.5 rounded font-bold">
                                      {time}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Hold Time Analysis Widget */}
              {result.holdTimeSummary && (
                <div className="p-5 rounded-2xl bg-neutral-900/20 border border-neutral-900/80 space-y-4">
                  <div className="flex items-center justify-between pb-2 border-b border-neutral-800/60 font-sans">
                    <div className="flex items-center gap-2">
                      <Music className="w-5 h-5 text-amber-500 animate-pulse" />
                      <h3 className="text-sm font-bold text-white">تدقيق ومراقبة وقت الهولد (الانتظار مع موسيقى عالية)</h3>
                    </div>
                    <span className="text-[10px] px-2.5 py-0.5 bg-amber-500/10 text-amber-400 border border-amber-500/20 rounded-full font-medium flex items-center gap-1">
                      <Music className="w-3 h-3" />
                      موسيقى انتظار عالية
                    </span>
                  </div>

                  <div className="p-3 bg-neutral-950/60 rounded-xl border border-neutral-800/60 text-xs text-neutral-400 leading-relaxed flex items-center gap-2">
                    <span className="text-amber-400 font-bold">معيار الهولد:</span>
                    <span>الهولد يُحتسب حصرياً عند تشغيل موسيقى انتظار عالية أو نغمة وضع العميل على الانتظار، ومفصول تماماً عن فترات الصمت العادية (الهدوء التام).</span>
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {/* Hold status indicator */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900 flex flex-col justify-between">
                      <span className="text-xs text-neutral-400 font-medium">حالة فترات الهولد</span>
                      <div className="mt-2 flex items-center">
                        {result.holdTimeSummary.holdCount > 0 ? (
                          <span className="text-xs px-2.5 py-1 bg-amber-500/10 text-amber-400 rounded-full border border-amber-500/25 font-bold flex items-center gap-1.5">
                            <Music className="w-3.5 h-3.5 text-amber-500 animate-bounce" />
                            تم رصد موسيقى هولد ({result.holdTimeSummary.holdCount})
                          </span>
                        ) : (
                          <span className="text-xs px-2.5 py-1 bg-emerald-500/10 text-emerald-400 rounded-full border border-emerald-500/25 font-bold flex items-center gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                            مكالمة بدون هولد
                          </span>
                        )}
                      </div>
                    </div>

                    {/* holdCount */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900 flex flex-col justify-between">
                      <span className="text-xs text-neutral-400 font-medium font-sans">عدد مرات وضع العميل بالانتظار (موسيقى)</span>
                      <span className="text-lg font-extrabold text-white mt-2">
                        {result.holdTimeSummary.holdCount} <span className="text-xs text-neutral-500 font-medium">مرات</span>
                      </span>
                    </div>

                    {/* totalHoldSeconds */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-950 flex flex-col justify-between">
                      <span className="text-xs text-neutral-400 font-medium font-sans">إجمالي وقت الانتظار (الهولد)</span>
                      <span className="text-lg font-extrabold text-amber-500 mt-2">
                        {result.holdTimeSummary.totalHoldSeconds} <span className="text-xs text-neutral-500 font-medium">ثانية</span>
                      </span>
                    </div>
                  </div>

                  {/* Hold segments details list if items exist */}
                  {result.holdTimeSummary.holdSegments && result.holdTimeSummary.holdSegments.length > 0 && (
                    <div className="pt-2">
                      <h4 className="text-xs font-bold text-neutral-400 mb-2">أوقات وتفاصيل فترات الانتظار (موسيقى عالية):</h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {result.holdTimeSummary.holdSegments.map((seg, idx) => (
                          <div key={idx} className="p-3 bg-neutral-950/60 rounded-lg border border-neutral-900 flex flex-col gap-1.5 text-xs">
                            <div className="flex items-center justify-between gap-2">
                              <div className="flex items-center gap-2">
                                <Music className="w-3.5 h-3.5 text-amber-400" />
                                <span className="text-neutral-200 font-semibold font-sans">فترة هولد رقم #{idx + 1}</span>
                              </div>
                              <div className="font-mono text-neutral-400 flex items-center gap-1">
                                <span>{seg.timeStart} ← {seg.timeEnd}</span>
                                <span className="text-neutral-700">•</span>
                                <span className="text-amber-500 font-bold">({seg.duration} ث)</span>
                              </div>
                            </div>
                            <div className="flex items-center justify-between text-[11px] pt-1 border-t border-neutral-900">
                              <span className="text-neutral-500">الطابع الصوتي المرصود:</span>
                              <span className="text-amber-400 font-medium flex items-center gap-1">
                                <Music className="w-3 h-3" />
                                {seg.audioCharacteristic || "موسيقى انتظار عالية"}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Agent Tone of Voice Assessment Widget */}
              {result.agentToneAnalysis && (
                <div id="tone-of-voice-audit-section" className="p-6 rounded-2xl bg-neutral-900/20 border border-neutral-800/80 space-y-5 animate-fade-in animate-duration-300">
                  <div className="flex items-center justify-between border-b border-neutral-800/60 pb-3">
                    <div className="flex items-center gap-2 font-sans">
                      <Volume2 className="w-5 h-5 text-amber-500 animate-pulse" />
                      <h3 className="text-sm font-bold text-white font-sans">تدقيق نبرة صوت الزميل</h3>
                    </div>
                    {/* Score badge out of 10 */}
                    <div className="flex items-center gap-1.5 px-3 py-1 bg-amber-500/10 text-amber-400 border border-amber-500/20 rounded-lg text-xs font-bold font-mono">
                      <span>تقييم النبرة:</span>
                      <span className="text-white text-sm">{result.agentToneAnalysis.score}</span>
                      <span className="text-neutral-500 font-normal">/10</span>
                    </div>
                  </div>

                  {/* Smile Presence Indicator Row */}
                  <div className={`p-4 rounded-xl border flex flex-col gap-3 ${
                    result.agentToneAnalysis.hasSmile 
                      ? "bg-emerald-500/5 border-emerald-500/10 text-emerald-400" 
                      : "bg-amber-500/5 border-amber-500/10 text-amber-400"
                  }`}>
                    <div className="flex items-start gap-2.5">
                      <Smile className={`w-5 h-5 shrink-0 mt-0.5 ${result.agentToneAnalysis.hasSmile ? "text-emerald-400" : "text-amber-400"}`} />
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs font-bold text-neutral-255">تدقيق حضور الابتسامة في الصوت:</span>
                          <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                            result.agentToneAnalysis.hasSmile 
                              ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" 
                              : "bg-rose-500/10 text-rose-450 border border-rose-500/20 font-bold"
                          }`}>
                            {result.agentToneAnalysis.hasSmile 
                              ? "مبتسمة وبها بشاشة صوتية" 
                              : (result.agentToneAnalysis.smileEvaluation?.includes("تردد") || result.agentToneAnalysis.detectedTraits?.some(t => t.includes("تردد")))
                                ? "غير مبتسمة (ينقصها الابتسامة وبها تردد أحياناً)" 
                                : "غير مبتسمة وينقصها الابتسامة"}
                          </span>
                        </div>
                        <p className="text-xs text-neutral-300 font-sans leading-relaxed">
                          {result.agentToneAnalysis.smileEvaluation}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Split Summaries Layout (Introduction vs Call) */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Introduction Summary */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900/80 space-y-2">
                      <span className="text-xs font-bold text-amber-400 font-sans block">خلاصة النبرة في المقدمة والافتتاحية:</span>
                      <p className="text-xs text-neutral-300 leading-relaxed font-sans">
                        {result.agentToneAnalysis.introductionSummary}
                      </p>
                    </div>

                    {/* Main Call Summary */}
                    <div className="p-4 bg-neutral-950/40 rounded-xl border border-neutral-900/80 space-y-2">
                      <span className="text-xs font-bold text-emerald-400 font-sans block">خلاصة النبرة خلال باقي المكالمة:</span>
                      <p className="text-xs text-neutral-300 leading-relaxed font-sans">
                        {result.agentToneAnalysis.callSummary}
                      </p>
                    </div>
                  </div>

                  {/* Character Traits/Tags */}
                  {result.agentToneAnalysis.detectedTraits && result.agentToneAnalysis.detectedTraits.length > 0 && (
                    <div className="space-y-2 pt-1">
                      <span className="text-[10px] text-neutral-400 font-bold font-sans">السمات والملحوظات الصوتية المكتشفة:</span>
                      <div className="flex flex-wrap gap-1.5">
                        {result.agentToneAnalysis.detectedTraits.map((trait, index) => {
                          const isBenchmarkToneTrait = trait.includes("ينقصها الابتسامة وبها تردد") || trait.includes("ينقصها الابتسامة وبها تردد أحياناً");
                          return (
                            <span
                              key={index}
                              className={`text-xs px-2.5 py-1 rounded-lg font-sans font-medium flex items-center gap-1.5 transition-all ${
                                isBenchmarkToneTrait
                                  ? "bg-amber-500/15 text-amber-300 border border-amber-500/40 font-bold shadow-sm shadow-amber-500/10"
                                  : "bg-neutral-950 text-neutral-200 border border-neutral-850"
                              }`}
                            >
                              <span className={`w-1.5 h-1.5 rounded-full ${isBenchmarkToneTrait ? "bg-amber-400 animate-pulse" : "bg-neutral-400"}`} />
                              {trait}
                              {isBenchmarkToneTrait && (
                                <span className="text-[9px] px-1.5 py-0.2 bg-amber-500/25 text-amber-300 rounded font-mono font-bold border border-amber-500/30">
                                  معيار النبرة
                                </span>
                              )}
                            </span>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Filtering tabs */}
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-neutral-900 pb-3">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold text-white">التفريغ النصي والجدول الزمني للمكالمة</span>
                  <span className="text-[11px] text-neutral-500 font-sans">
                    ({filteredTranscript?.length || 0} مقطع)
                  </span>
                </div>
                <div className="flex flex-wrap gap-1 text-xs bg-neutral-900 p-1 rounded-lg border border-neutral-800/80">
                  <button
                    id="filter-all"
                    onClick={() => setActiveSegmentFilter("all")}
                    className={`px-3 py-1.5 rounded-md font-medium transition-all ${
                      activeSegmentFilter === "all" ? "bg-neutral-800 text-white shadow" : "text-neutral-400 hover:text-white"
                    }`}
                  >
                    عرض الكل
                  </button>
                  <button
                    id="filter-customer"
                    onClick={() => setActiveSegmentFilter("customer")}
                    className={`px-3 py-1.5 rounded-md font-medium transition-all flex items-center gap-1.5 ${
                      activeSegmentFilter === "customer" 
                        ? "bg-purple-500/20 text-purple-300 border border-purple-500/30" 
                        : "text-neutral-400 hover:text-white"
                    }`}
                  >
                    <User className="w-3 h-3 text-purple-400" />
                    صوت العميل فقط
                  </button>
                  <button
                    id="filter-agent"
                    onClick={() => setActiveSegmentFilter("agent")}
                    className={`px-3 py-1.5 rounded-md font-medium transition-all flex items-center gap-1.5 ${
                      activeSegmentFilter === "agent" 
                        ? "bg-blue-500/20 text-blue-300 border border-blue-500/30" 
                        : "text-neutral-400 hover:text-white"
                    }`}
                  >
                    <Headphones className="w-3 h-3 text-blue-400" />
                    صوت الموظف فقط
                  </button>
                  <button
                    id="filter-silence"
                    onClick={() => setActiveSegmentFilter("silence")}
                    className={`px-3 py-1.5 rounded-md font-medium transition-all flex items-center gap-1.5 ${
                      activeSegmentFilter === "silence" 
                        ? "bg-rose-500/20 text-rose-300 border border-rose-500/30" 
                        : "text-neutral-400 hover:text-white"
                    }`}
                  >
                    <AlertTriangle className="w-3 h-3 text-rose-400" />
                    فترات الصمت فقط
                  </button>
                </div>
              </div>

              {/* Chat Timeline list */}
              <div className="space-y-4">
                {filteredTranscript && filteredTranscript.length > 0 ? (
                  filteredTranscript.map((segment, index) => {
                    const isSilence = segment.speaker.includes("صمت") || segment.speaker.includes("صمت الموظف") || segment.speaker.includes("فترة صمت الموظف");
                    const isAgent = segment.speaker.includes("موظف") || segment.speaker.includes("كول سنتر");

                    return (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.05 }}
                        className={`p-4 rounded-xl border flex flex-col gap-2.5 transition-all ${
                          isSilence 
                            ? "bg-rose-500/5 border-rose-500/10 text-rose-200"
                            : isAgent 
                              ? "bg-blue-500/5 border-blue-500/10 text-neutral-100"
                              : "bg-purple-500/5 border-purple-500/10 text-purple-100"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            {isSilence ? (
                              <div className="flex items-center gap-1.5 bg-rose-500/10 text-rose-400 text-[11px] px-2 py-0.5 rounded-md border border-rose-500/20 font-bold">
                                <AlertTriangle className="w-3.5 h-3.5" />
                                {segment.speaker}
                              </div>
                            ) : isAgent ? (
                              <div className="flex items-center gap-1.5 bg-blue-500/10 text-blue-400 text-[11px] px-2 py-0.5 rounded-md border border-blue-500/25 font-bold">
                                <Headphones className="w-3.5 h-3.5" />
                                {segment.speaker}
                              </div>
                            ) : (
                              <div className="flex items-center gap-1.5 bg-purple-500/10 text-purple-400 text-[11px] px-2 py-0.5 rounded-md border border-purple-500/25 font-bold">
                                <User className="w-3.5 h-3.5" />
                                {segment.speaker}
                              </div>
                            )}
                          </div>
                          
                          {/* Timestamps */}
                          <div className="flex items-center gap-2 text-neutral-500 text-xs font-mono font-medium">
                            <Clock className="w-3.5 h-3.5" />
                            <span>{segment.timeStart} ← {segment.timeEnd}</span>
                            <span className="text-neutral-700">•</span>
                            <span className="text-[11px] bg-neutral-950 px-2 py-0.5 rounded border border-neutral-900">{segment.duration} ثانية</span>
                          </div>
                        </div>

                        {/* Transcript context text */}
                        <div className="text-sm font-sans leading-relaxed">
                          {isSilence ? (
                            <span className="italic text-rose-400 font-medium">
                              {segment.text} [صمت غير مبرر للزميل تم احتسابه]
                            </span>
                          ) : isAgent ? (
                            <span className="text-blue-100/95 font-medium">{segment.text}</span>
                          ) : (
                            <span className="text-purple-200 font-medium">{segment.text}</span>
                          )}
                        </div>
                      </motion.div>
                    );
                  })
                ) : (
                  <div className="text-center py-12 text-neutral-500 text-sm">
                    لا تتوفر وسوم أو مقاطع تطابق معيار التصفية المختار.
                  </div>
                )}
              </div>

            </motion.div>
          )}

        </AnimatePresence>

      </main>

      {/* Footer information bar */}
      <footer className="border-t border-neutral-900 bg-neutral-950 py-4 px-6 mt-12">
        <div className="max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-neutral-500">
          <div>
            دقة تامة لتقاط اللهجة المصرية والتحليل الاستقرائي للصمت.
          </div>
          <div className="font-mono text-neutral-600">
            © {new Date().getFullYear()} QA Auditor Tool
          </div>
        </div>
      </footer>

    </div>
  );
}
