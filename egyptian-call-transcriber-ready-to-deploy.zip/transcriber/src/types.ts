export interface TranscriptItem {
  speaker: "العميل" | "موظف خدمة العملاء" | "فترة صمت الموظف" | string;
  text: string;
  timeStart: string;
  timeEnd: string;
  duration: number; // in seconds
}

export interface SilenceSegment {
  timeStart: string; // وقت بداية الصمت (نهاية آخر كلمة للمتحدث السابق)
  timeEnd: string;   // وقت نهاية الصمت (بداية أول كلمة للمتحدث اللاحق)
  duration: number;  // مدة الصمت بالثواني
  fromSpeaker: string; // المتحدث السابق قبل فترة الصمت (العميل أو موظف خدمة العملاء)
  toSpeaker: string;   // المتحدث اللاحق بعد فترة الصمت (العميل أو موظف خدمة العملاء)
  description: string; // تفصيل بالعامية المصرية يصف الفترة
  type?: "quiet_silence" | "hold_music"; // نوع الفترة (هدوء تام وخلو من الصوت)
}

export interface AgentSilenceSummary {
  totalSilenceSeconds: number;
  silenceCount: number;
  silenceRatio: number; // percentage (e.g., 15)
  silenceSegments?: SilenceSegment[];
}

export interface CustomerNameAnalysis {
  customerNameDetected: string; // الاسم المكتشف للعميل، أو فارغ إذا لم يكتشف
  isMentionedByAgent: boolean; // هل تم ذكره بواسطة الموظف أم لا
  mentionCount: number; // عدد مرات ذكر الاسم بواسطة الموظف
  mentionsTimestamps: string[]; // الطوابع الزمنية التي ذكر فيها الموظف اسم العميل
}

export interface HoldSegment {
  timeStart: string;
  timeEnd: string;
  duration: number;
  hasLoudMusic?: boolean; // هل تصاحبها موسيقى انتظار عالية أو نغمة
  audioCharacteristic?: string; // وصف صوتي مثل: "موسيقى انتظار صريحة وعالية"، "نغمة هولد"
}

export interface HoldTimeSummary {
  totalHoldSeconds: number;
  holdCount: number;
  holdSegments: HoldSegment[];
}

export interface GreetingAnalysis {
  isGreetingUsed: boolean; // هل تم استخدام عبارات الترحيب مثل أهلاً، نورتنا، شرفتنا
  detectedGreetingPhrases: string[]; // عبارات الترحيب المحددة المكتشفة في المقدمة
  greetingTimestamps: string[]; // الطوابع الزمنية التي ذكر فيها الزميل عبارة الترحيب بصيغة MM:SS
  greetingTextSnippet: string; // نص الترحيب الذي نطق به الزميل في المقدمة
  evaluation: string; // تقييم جودة الترحيب بالعامية المصرية
}

export interface EmpathyAnalysis {
  isEmpathyUsed: boolean; // هل تم استخدام عبارات التعاطف المحددة (ألف سلامة / بالشفاء)
  detectedEmpathyPhrases: string[]; // العبارات المكتشفة (ألف سلامة أو بالشفاء)
  empathyCount: number; // عدد مرات ذكر عبارات التعاطف المكتشفة
  empathyTimestamps: string[]; // الطوابع الزمنية التي قيلت فيها عبارات التعاطف بصيغة MM:SS
  empathyTextSnippet: string; // الجملة التي قيل فيها التعاطف
  evaluation: string; // تقييم التعاطف (مثلاً: "تم التعاطف" أو "لم يتم التعاطف")
}

export interface FurtherAssistanceAnalysis {
  isAssistanceOffered: boolean; // هل عرض الزميل خدمات أخرى قبل الانهاء (مثل أي مساعدة أخرى أو إضافة شيء آخر)
  detectedAssistancePhrases: string[]; // عبارات عرض المساعدة المكتشفة
  assistanceTextSnippet: string; // نص جملة عرض المساعدة الإضافية الفعلي
  evaluation: string; // تقييم عرض الخدمات الأخرى قبل الإنهاء (مثلاً: "تم عرض خدمات أخرى" أو "لم يتم عرض خدمات أخرى")
}

export interface UnprofessionalWordDetail {
  word: string;
  count: number;
  timestamps: string[];
}

export interface UnprofessionalWordsAnalysis {
  hasUnprofessionalWords: boolean;
  totalUnprofessionalWordsCount: number;
  detectedWords: UnprofessionalWordDetail[];
  evaluation: string;
}

export interface CallEndingAnalysis {
  isEndingPhraseUsed: boolean; // هل تم قول شرفتنا أو شرتنا أو شكرا لاتصالك عند الانتهاء والوداع
  detectedEndingPhrases: string[]; // الكلمات المكتشفة من القائمة الحصرية (شرفتنا، شرفت، شكرا لاتصالك)
  endingTextSnippet: string; // نص جملة الإنهاء الفعلي التي تلفظ بها الزميل في نهاية المكالمة
  evaluation: string; // التقييم الفني لجودة الوداع وإنهاء المكالمة بالعامية المصرية
}

export interface CustomerTitleAnalysis {
  titleDetected: string; // اللقب الفعلي المكتشف للعميل (مثل دكتور / مستشار / مهندس / أستاذ)
  isTitleUsedByAgent: boolean; // هل أظهر الزميل اهتماماً ونطق لقب العميل المناسب باحترافية؟
  titleMentionCount: number; // عدد مرات ذكر اللقب بواسطة الموظف
  titleMentionsTimestamps: string[]; // الطوابع الزمنية لذكر اللقب بصيغة MM:SS
  titleTextSnippet: string; // السطر أو العبارة الفعلية التي تلفظ فيها الزميل باللقب
  evaluation: string; // التقييم والتحليل الفني لاستخدام الألقاب المهنية أو غيابها بالعامية المصرية
}

export interface AgentApologyAnalysis {
  isApologyNeeded: boolean; // هل تطلب سياق المكالمة اعتذاراً (مثل هولد طويل، خطأ، انقطاع)؟
  isApologyUsedByAgent: boolean; // هل قدم الزميل اعتذاراً صريحاً (آسف/بعتذر/متأسف/عذراً)؟
  apologyMentionCount: number; // عدد مرات تقديم الاعتذار
  apologyTimestamps: string[]; // الطوابع الزمنية للاعتذار بصيغة MM:SS
  apologyTextSnippet: string; // الجملة أو العبارة الفعلية للاعتذار من الزميل
  evaluation: string; // التقييم الفني لمرونة ولباقة الزميل في الاعتذار بالعامية المصرية
}

export interface AgentToneAnalysis {
  introductionSummary: string; // خلاصة نبرة الصوت في المقدمة بالعامية المصرية
  callSummary: string; // خلاصة نبرة الصوت خلال باقي المكالمة بالعامية المصرية
  hasSmile: boolean; // هل نبرة الصوت بها ابتسامة أم لا (مبتسمة / غير مبتسمة)
  smileEvaluation: string; // النقد والتعقيب على حضور الابتسامة والبشاشة بالعامية المصرية
  detectedTraits: string[]; // سمات النبرة الملحوظة مثل (بها ابتسامة، ينقصها الابتسامة، هادئة، بها تردد، ينقصها التفاعل، جافة، ودودة، إلخ.)
  score: number; // تقييم إجمالي للنبرة من 10
}

export interface VerbalTicDetail {
  word: string;
  count: number;
  timestamps: string[];
}

export interface VerbalTicsAnalysis {
  hasVerbalTics: boolean;
  detectedTics: VerbalTicDetail[];
  evaluation: string;
}

export interface EngineInfo {
  whisperApiUsed: boolean;
  qwenCleoUsed?: boolean;
  qwenCleoAvailable?: boolean;
  engineName: string;
  faintAudioCaptured: boolean;
  speakerDiarizationEnabled: boolean;
}

export interface TranscriptionResponse {
  transcript: TranscriptItem[];
  agentSilenceSummary: AgentSilenceSummary;
  customerNameAnalysis: CustomerNameAnalysis;
  customerTitleAnalysis?: CustomerTitleAnalysis;
  agentApologyAnalysis?: AgentApologyAnalysis;
  holdTimeSummary: HoldTimeSummary;
  greetingAnalysis: GreetingAnalysis;
  empathyAnalysis: EmpathyAnalysis;
  furtherAssistanceAnalysis: FurtherAssistanceAnalysis;
  unprofessionalWordsAnalysis?: UnprofessionalWordsAnalysis;
  callEndingAnalysis?: CallEndingAnalysis;
  agentToneAnalysis?: AgentToneAnalysis; // التحديث الجديد لنبرة صوت الزميل
  verbalTicsAnalysis?: VerbalTicsAnalysis; // تحليل اللازمات اللفظية وتكرار الكلمات المتكرر للزملاء
  isBenchmark?: boolean; // هل المكالمة معيارية مرجعية Benchmark
  benchmarkNotes?: string; // ملاحظات المعايرة القياسية للمكالمة
  _engineInfo?: EngineInfo;
}


