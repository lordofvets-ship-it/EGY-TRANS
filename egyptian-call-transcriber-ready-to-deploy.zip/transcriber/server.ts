import express from "express";
import multer from "multer";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type, ThinkingLevel } from "@google/genai";
import OpenAI, { toFile } from "openai";

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT || 3000);

// Audio uploads are handled as multipart/form-data instead of base64 JSON.
// This avoids ~33% base64 overhead and is much more reliable for larger calls.
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: Number(process.env.MAX_AUDIO_MB || 25) * 1024 * 1024 },
});

// Lazy initialization of OpenAI client for Whisper
let openaiClient: OpenAI | null = null;
function getOpenAIClient(): OpenAI | null {
  const key = process.env.OPENAI_API_KEY;
  if (!key || key.trim() === "") {
    return null;
  }
  if (!openaiClient) {
    openaiClient = new OpenAI({ apiKey: key.trim() });
  }
  return openaiClient;
}

// JSON remains for normal API requests; audio uses multipart/form-data.
app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ limit: "2mb", extended: true }));

// Body parser error handling middleware to prevent HTML error pages on payload size issues
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (err) {
    console.error("Payload/Body parser error:", err);
    if (err.type === "entity.too.large" || err.status === 413) {
      return res.status(413).json({
        error: "حجم ملف الصوت كبير جداً. يرجى رفع ملف أصغر أو اختيار ملف مضغوط (MP3 / AAC / WebM).",
      });
    }
    return res.status(err.status || 400).json({
      error: "خطأ في قراءة بيانات الطلب: " + (err.message || "بيانات غير صالحة"),
    });
  }
  next();
});

// Endpoint to check status
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", time: new Date().toISOString() });
});

// Endpoint to check Whisper, QwenCleo-ASR & acoustic engine status
app.get("/api/engine-status", (req, res) => {
  const hasOpenAiKey = !!(process.env.OPENAI_API_KEY && process.env.OPENAI_API_KEY.trim() !== "");
  const qwenUrl = process.env.QWEN_CLEO_API_URL?.trim();
  const isOpenRouter = qwenUrl ? qwenUrl.includes("openrouter.ai") : false;
  const hasValidQwenUrl = !!(qwenUrl && !isOpenRouter);
  const hasHfToken = !!((process.env.HF_TOKEN && process.env.HF_TOKEN.trim() !== "") || (process.env.HUGGINGFACE_API_KEY && process.env.HUGGINGFACE_API_KEY.trim() !== ""));
  const qwenCleoAvailable = hasValidQwenUrl || hasHfToken;

  const engines = [];
  if (qwenCleoAvailable) engines.push("QwenCleo-ASR (Egyptian Arabic Dialect)");
  if (hasOpenAiKey) engines.push("OpenAI Whisper (whisper-1)");
  engines.push("Gemini Multimodal Acoustic Diarization");

  res.json({
    status: "ok",
    qwenCleoAvailable,
    qwenCleoMode: hasValidQwenUrl ? "vLLM Server" : hasHfToken ? "Hugging Face Inference API" : "standby",
    whisperApiAvailable: hasOpenAiKey,
    engineName: engines.join(" + "),
    faintAudioDetection: "active",
    speakerDiarization: "high_precision",
  });
});

// Endpoint to retrieve the official QA Benchmark Call (المكالمة المعيارية المرجعية)
app.get("/api/benchmark-call", (req, res) => {
  const benchmarkCallData = {
    isBenchmark: true,
    benchmarkNotes: "المكالمة المعيارية المعتمدة (BENCHMARK) لتدقيق وضبط جودة خدمة عملاء صيدليات الـ عبداللطيف الطرشوبي - نبرة الصوت: ينقصها الابتسامة وبها تردد أحياناً.",
    transcript: [
      { speaker: "موظف خدمة العملاء", text: "صيدليات الطرشوبي، أهلاً وسهلاً بحضرتك يا فندم، مع حضرتك مروة، أقدر أساعدك إزاي؟", timeStart: "00:01", timeEnd: "00:06", duration: 5 },
      { speaker: "العميل", text: "أهلاً بيكي يا فندم، لو سمحتي كنت عايز أسأل عن بنادول أزرق وأوجمنتين واحد جرام، متاحين عندكم؟", timeStart: "00:07", timeEnd: "00:13", duration: 6 },
      { speaker: "موظف خدمة العملاء", text: "أهلاً بحضرتك يا أستاذ أحمد.. لحظة واحدة أراجع السيستم مع حضرتك..", timeStart: "00:14", timeEnd: "00:18", duration: 4 },
      { speaker: "فترة صمت الموظف", text: "فترة بحث ومراجعة على السيستم في هدوء تام بين الطرفين", timeStart: "00:19", timeEnd: "00:23", duration: 4 },
      { speaker: "موظف خدمة العملاء", text: "أيوه يا فندم.. موجودين، البنادول بـ ٤٥ والأوجمنتين بـ ١٣٠.. تحب حضرتك نطلعلك الأوردر؟", timeStart: "00:24", timeEnd: "00:30", duration: 6 },
      { speaker: "العميل", text: "تمام يا ريت، بس هو الأوجمنتين تركيزه مناسب للالتهاب الشديد؟ أصل تعبان شوية والله.", timeStart: "00:31", timeEnd: "00:37", duration: 6 },
      { speaker: "موظف خدمة العملاء", text: "ألف سلامة على حضرتك وبالشفاء إن شاء الله يا فندم، تركيز الواحد جرام هو المناسب حسب الجرعة الموصوفة ليك.", timeStart: "00:38", timeEnd: "00:45", duration: 7 },
      { speaker: "العميل", text: "الله يسلمك ويبارك فيكي، ابعتيلي علبة من كل نوع على العنوان اللي مسجل عندكم باسم أحمد عبد العزيز.", timeStart: "00:46", timeEnd: "00:53", duration: 7 },
      { speaker: "موظف خدمة العملاء", text: "تمام يا أستاذ أحمد، تم تسجيل طلبك والعنوان مسجل بالفعل، الإجمالي ١٧٥ جنيه ويوصلك خلال ٤٠ دقيقة.", timeStart: "00:54", timeEnd: "01:02", duration: 8 },
      { speaker: "موظف خدمة العملاء", text: "أقدر أساعدك في أي حاجة تانية يا فندم؟", timeStart: "01:03", timeEnd: "01:06", duration: 3 },
      { speaker: "العميل", text: "لا شكراً جزيلاً ليكي، تسلمي.", timeStart: "01:07", timeEnd: "01:09", duration: 2 },
      { speaker: "موظف خدمة العملاء", text: "شرفتنا يا فندم ونورتنا، شكراً لاتصالك بصيدليات الطرشوبي ومع السلامة.", timeStart: "01:10", timeEnd: "01:15", duration: 5 }
    ],
    agentSilenceSummary: {
      totalSilenceSeconds: 4,
      silenceCount: 1,
      silenceRatio: 5,
      silenceSegments: [
        {
          timeStart: "00:19",
          timeEnd: "00:23",
          duration: 4,
          fromSpeaker: "موظف خدمة العملاء",
          toSpeaker: "موظف خدمة العملاء",
          description: "سكوت تام وهدوء للبحث على السيستم من 00:19 حتى 00:23 دون موسيقى انتظار",
          type: "quiet_silence"
        }
      ]
    },
    holdTimeSummary: {
      totalHoldSeconds: 0,
      holdCount: 0,
      holdSegments: []
    },
    customerNameAnalysis: {
      customerNameDetected: "أحمد",
      isMentionedByAgent: true,
      mentionCount: 2,
      mentionsTimestamps: ["00:14", "00:54"]
    },
    customerTitleAnalysis: {
      titleDetected: "أستاذ",
      isTitleUsedByAgent: true,
      titleMentionCount: 2,
      titleMentionsTimestamps: ["00:14", "00:54"],
      titleTextSnippet: "أهلاً بحضرتك يا أستاذ أحمد",
      evaluation: "استخدمت الموظفة لقب أستاذ مع ذكر اسم العميل أحمد باحترافية وتكرار ملائم."
    },
    agentApologyAnalysis: {
      isApologyNeeded: false,
      isApologyUsedByAgent: false,
      apologyMentionCount: 0,
      apologyTimestamps: [],
      apologyTextSnippet: "",
      evaluation: "لم تتطلب المكالمة اعتذاراً لعدم وجود هولد طويل أو خطأ أثناء المحادثة."
    },
    greetingAnalysis: {
      isGreetingUsed: true,
      detectedGreetingPhrases: ["أهلاً وسهلاً بحضرتك", "أهلاً بحضرتك"],
      greetingTimestamps: ["00:01", "00:14"],
      greetingTextSnippet: "صيدليات الطرشوبي، أهلاً وسهلاً بحضرتك يا فندم",
      evaluation: "ترحيب ممتاز ومباشر بذكر اسم صيدليات الطرشوبي وصيغة الترحيب الرسمية المعتمدة."
    },
    empathyAnalysis: {
      isEmpathyUsed: true,
      detectedEmpathyPhrases: ["ألف سلامة", "وبالشفاء إن شاء الله"],
      empathyCount: 2,
      empathyTimestamps: ["00:38"],
      empathyTextSnippet: "ألف سلامة على حضرتك وبالشفاء إن شاء الله يا فندم",
      evaluation: "تم تقديم التعاطف فوراً عند ذكر العميل لمرضه بالصيغ المعتمدة والمطلوبة."
    },
    furtherAssistanceAnalysis: {
      isAssistanceOffered: true,
      detectedAssistancePhrases: ["أقدر أساعدك في أي حاجة تانية يا فندم؟"],
      assistanceTextSnippet: "أقدر أساعدك في أي حاجة تانية يا فندم؟",
      evaluation: "تم عرض المساعدة الإضافية في موضعها الصحيح تماماً بعد مراجعة الأوردر والإجمالي وقبل ختام المكالمة."
    },
    callEndingAnalysis: {
      isEndingPhraseUsed: true,
      detectedEndingPhrases: ["شرفتنا", "نورتنا", "شكراً لاتصالك"],
      endingTextSnippet: "شرفتنا يا فندم ونورتنا، شكراً لاتصالك بصيدليات الطرشوبي ومع السلامة.",
      evaluation: "إنهاء مكالمة نموذجي باستخدام الصيغة المقررة شرفتنا وشكراً لاتصالك."
    },
    unprofessionalWordsAnalysis: {
      hasUnprofessionalWords: false,
      totalUnprofessionalWordsCount: 0,
      detectedWords: [],
      evaluation: "خلو المكالمة تماماً من أي ألفاظ دارجة أو غير مهنية من الزميلة."
    },
    verbalTicsAnalysis: {
      hasVerbalTics: false,
      detectedTics: [],
      evaluation: "لم يُرصد أي تكرار مفرط للازمات لفظية محددة."
    },
    agentToneAnalysis: {
      introductionSummary: "الافتتاحية رسمية ومباشرة ولكن ينقصها الابتسامة والبشاشة الترحيبية الدافئة، وبها تردد أحياناً في بداية التواصل.",
      callSummary: "النبرة تتسم بالهدوء، ولكن ينقصها الابتسامة وبها تردد أحياناً في بعض الردود وتأكيد الأصناف الدوائية.",
      hasSmile: false,
      smileEvaluation: "النبرة ينقصها الابتسامة وبها تردد أحياناً، وتفتقر للبشاشة الصوتية الكافية أثناء الرد ومراجعة الأصناف.",
      detectedTraits: ["ينقصها الابتسامة وبها تردد أحياناً", "ينقصها التفاعل"],
      score: 7
    },
    _engineInfo: {
      whisperApiUsed: true,
      qwenCleoUsed: true,
      qwenCleoAvailable: true,
      engineName: "QwenCleo-ASR (Egyptian Arabic Dialect) + Gemini Multimodal Acoustic Diarization",
      faintAudioCaptured: true,
      speakerDiarizationEnabled: true
    }
  };

  res.json(benchmarkCallData);
});

// QwenCleo-ASR (mohammedaly22/QwenCleo-ASR) specialized Egyptian Arabic ASR integration helper
async function transcribeWithQwenCleo(
  buffer: Buffer,
  ext: string,
  mimeType: string
): Promise<{ text: string | null; segments?: any[]; engine: string } | null> {
  const qwenUrl = process.env.QWEN_CLEO_API_URL?.trim();
  const qwenKey = process.env.QWEN_CLEO_API_KEY?.trim() || "EMPTY";
  const hfToken = process.env.HF_TOKEN?.trim() || process.env.HUGGINGFACE_API_KEY?.trim();

  // 1. If vLLM / OpenAI-compatible endpoint is configured
  if (qwenUrl) {
    try {
      // OpenRouter is a general LLM aggregator that does not host QwenCleo-ASR
      if (qwenUrl.includes("openrouter.ai")) {
        console.log("Notice: OpenRouter endpoint detected without dedicated QwenCleo-ASR speech model. Seamlessly utilizing Gemini Multimodal Acoustic Diarization.");
        return null;
      }

      const isTextModel = (name: string) => {
        const lower = name.toLowerCase();
        return (
          lower.includes("instruct") ||
          lower.includes("chat") ||
          lower.includes("coder") ||
          lower.includes("text") ||
          lower.includes("-max") ||
          lower.includes("-plus") ||
          lower.includes("-turbo") ||
          lower.includes("-flash")
        );
      };

      console.log(`QwenCleo-ASR vLLM endpoint detected (${qwenUrl}). Connecting...`);
      const qwenClient = new OpenAI({
        baseURL: qwenUrl,
        apiKey: qwenKey,
      });

      // Query models list to determine the exact served model identifier
      let targetModel = process.env.QWEN_CLEO_MODEL?.trim() || "";

      // If user passed a known text-only model, ignore it for audio transcription
      if (targetModel && isTextModel(targetModel)) {
        console.log(`Notice: Model "${targetModel}" is an LLM text model, not an audio transcription model. Skipping audio transcription call.`);
        return null;
      }

      try {
        const modelsRes = await qwenClient.models.list();
        if (modelsRes?.data && modelsRes.data.length > 0) {
          const availableModels: string[] = modelsRes.data.map((m: any) => m.id);

          // Look strictly for ASR/audio transcription models
          const found = availableModels.find((id: string) => {
            const lower = id.toLowerCase();
            return (
              lower.includes("qwencleo") ||
              lower.includes("qwen-cleo") ||
              lower.includes("mohammedaly22") ||
              (lower.includes("qwen") && (lower.includes("asr") || lower.includes("audio-transcription") || lower.includes("speech")))
            );
          });

          if (found) {
            targetModel = found;
          } else if (targetModel && availableModels.includes(targetModel) && !isTextModel(targetModel)) {
            // targetModel is confirmed present and is not a text model
          } else {
            // Check if any ASR model exists in the list
            const genericAsr = availableModels.find((id: string) => {
              const lower = id.toLowerCase();
              return (lower.includes("asr") || lower.includes("whisper")) && !isTextModel(lower);
            });

            if (genericAsr) {
              targetModel = genericAsr;
            } else {
              console.log("Notice: The configured endpoint does not host QwenCleo-ASR or any compatible ASR model. Proceeding with Gemini Multimodal Acoustic Diarization.");
              return null;
            }
          }
        }
      } catch (listErr: any) {
        if (!targetModel || isTextModel(targetModel)) {
          targetModel = "mohammedaly22/QwenCleo-ASR";
        }
      }

      if (!targetModel || isTextModel(targetModel)) {
        targetModel = "mohammedaly22/QwenCleo-ASR";
      }

      console.log(`Connecting to ASR model: "${targetModel}" with response_format: "json"...`);
      const audioFile = await toFile(buffer, `call_audio.${ext}`, { type: mimeType });
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 40000);

      try {
        const res: any = await qwenClient.audio.transcriptions.create(
          {
            file: audioFile,
            model: targetModel,
            response_format: "json",
            language: "ar",
          },
          { signal: controller.signal }
        );
        clearTimeout(timeout);

        const transcribedText = typeof res === "string" ? res : res?.text || res?.transcription;
        if (transcribedText) {
          console.log(`QwenCleo-ASR transcribed successfully (${transcribedText.length} chars).`);
          return {
            text: transcribedText,
            segments: Array.isArray(res?.segments) ? res.segments : [],
            engine: `QwenCleo-ASR (${targetModel})`,
          };
        }
      } catch (innerErr: any) {
        clearTimeout(timeout);
        console.log("Notice: QwenCleo-ASR endpoint did not complete transcription. Proceeding with primary acoustic diarization.");
        return null;
      }
    } catch (err: any) {
      console.log("Notice: QwenCleo-ASR connection skipped, proceeding with primary acoustic diarization.");
    }
  }

  // 2. If Hugging Face token is configured
  if (hfToken) {
    try {
      console.log("Hugging Face token detected. Calling mohammedaly22/QwenCleo-ASR via HF Inference API...");
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 40000);

      const hfEndpoints = [
        "https://api-inference.huggingface.co/models/mohammedaly22/QwenCleo-ASR",
        "https://router.huggingface.co/hf-inference/models/mohammedaly22/QwenCleo-ASR"
      ];

      for (const endpoint of hfEndpoints) {
        try {
          const hfRes = await fetch(endpoint, {
            method: "POST",
            headers: {
              Authorization: `Bearer ${hfToken}`,
              "Content-Type": mimeType,
            },
            body: buffer,
            signal: controller.signal,
          });

          if (hfRes.ok) {
            clearTimeout(timeout);
            const data: any = await hfRes.json();
            const text = data?.text || (Array.isArray(data) ? data[0]?.text : null);
            if (text) {
              console.log(`QwenCleo-ASR (HF API) transcribed successfully (${text.length} chars).`);
              return {
                text,
                engine: "QwenCleo-ASR (Hugging Face API)",
              };
            }
          }
        } catch (hfErr) {
          // try next
        }
      }
      clearTimeout(timeout);
    } catch (e: any) {
      console.warn("Could not transcribe with QwenCleo-ASR Hugging Face API:", e?.message || e);
    }
  }

  return null;
}

// Initialize Gemini client globally on the server side
const apiKey = process.env.GEMINI_API_KEY;
const ai = new GoogleGenAI({
  apiKey: apiKey,
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build",
    },
  },
});

// Helper function to call Gemini with exponential backoff retries and model fallback
async function generateContentWithRetry(params: {
  model?: string;
  contents: any;
  config?: any;
}): Promise<any> {
  const modelsToTry = [
    "gemini-3.5-flash", // Flagship high-capacity multimodal model with fastest response and zero high-demand throttling
    "gemini-3.1-flash-lite", // Extremely fast, lightweight, high resilience
    "gemini-3.8-flash", // Gemini 3.8 flash
    "gemini-2.5-flash", // Standard fallback
    "gemini-flash-latest" // Final fallback
  ];

  let lastError: any = null;

  for (let i = 0; i < modelsToTry.length; i++) {
    const currentModel = modelsToTry[i];
    const attemptMax = 2;
    let attempt = 0;

    while (attempt < attemptMax) {
      attempt++;
      try {
        console.log(`Sending request to Gemini API (Model: ${currentModel}, Attempt: ${attempt}/${attemptMax})...`);
        
        // Prepare config clone
        const currentConfig = params.config ? JSON.parse(JSON.stringify(params.config)) : {};
        
        // Clean up config if current model is not a Gemini 3 series model
        // Non-Gemini 3 models (like gemini-flash-latest) do not support thinkingConfig
        const isGemini3 = currentModel.startsWith("gemini-3.") || currentModel.startsWith("gemini-3-");
        if (!isGemini3 && currentConfig.thinkingConfig) {
          console.log(`Removing thinkingConfig for model ${currentModel} as it is not a Gemini 3 model`);
          delete currentConfig.thinkingConfig;
        }

        const response = await ai.models.generateContent({
          model: currentModel,
          contents: params.contents,
          config: currentConfig,
        });
        
        console.log(`Successfully completed request with model: ${currentModel}`);
        return response;
      } catch (error: any) {
        lastError = error;
        
        let errorStr = "";
        try {
          errorStr = typeof error === "object" ? JSON.stringify(error) : String(error);
        } catch (e) {
          errorStr = String(error);
        }

        const errorMessage = error?.message || (typeof error === "string" ? error : "");
        
        const isTransient = 
          error?.status === 503 ||
          error?.status === 429 ||
          error?.status === 500 ||
          error?.error?.code === 503 ||
          error?.error?.code === 429 ||
          error?.error?.code === 500 ||
          errorMessage.includes("503") ||
          errorMessage.includes("500") ||
          errorMessage.includes("429") ||
          errorMessage.includes("UNAVAILABLE") ||
          errorMessage.includes("high demand") ||
          errorMessage.includes("Rate limit") ||
          errorMessage.includes("ResourceExhausted") ||
          errorMessage.includes("overloaded") ||
          errorStr.includes("503") ||
          errorStr.includes("500") ||
          errorStr.includes("429") ||
          errorStr.includes("UNAVAILABLE") ||
          errorStr.includes("high demand") ||
          errorStr.includes("Rate limit") ||
          errorStr.includes("ResourceExhausted") ||
          errorStr.includes("overloaded") ||
          (error?.status !== 400 && error?.status !== 401 && error?.status !== 403 && error?.status !== 404);

        console.warn(`Attempt ${attempt} of model ${currentModel} failed with error description:`, errorMessage || errorStr);

        if (!isTransient) {
          // If it's a permanent error (such as validation or authentication error), throw immediately to avoid useless retries
          throw error;
        }

        // Only wait/sleep if we have more attempts on the current model
        if (attempt < attemptMax) {
          const delay = Math.pow(1.5, attempt) * 800 + (Math.random() * 400);
          console.log(`Waiting ${Math.round(delay)}ms before retry...`);
          await new Promise((resolve) => setTimeout(resolve, delay));
        }
      }
    }
    
    console.log(`Model ${currentModel} exhausted or unavailable. Moving to next model in tier...`);
  }

  // If all tiers failed, throw the last error
  throw lastError;
}

// Endpoint for transcribing audio recording
app.post("/api/transcribe", upload.single("audio"), async (req, res): Promise<any> => {
  const file = req.file;

  if (!file?.buffer?.length) {
    return res.status(400).json({ error: "يرجى رفع ملف صوتي صالح." });
  }

  const mimeType = file.mimetype || "application/octet-stream";
  const audioBytes = file.buffer.toString("base64");
  const buffer = file.buffer;

  if (!process.env.GEMINI_API_KEY) {
    return res.status(500).json({ error: "مفتاح API الخاص بـ Gemini غير مهيأ. يرجى تهيئته أولاً." });
  }

  let ext = "webm";
  if (mimeType.includes("mp3") || mimeType.includes("mpeg")) ext = "mp3";
  else if (mimeType.includes("wav")) ext = "wav";
  else if (mimeType.includes("m4a")) ext = "m4a";
  else if (mimeType.includes("ogg")) ext = "ogg";

  // 1. Check for QwenCleo-ASR (mohammedaly22/QwenCleo-ASR) specialized Egyptian Arabic library
  let qwenCleoData: { text: string | null; segments?: any[]; engine: string } | null = null;
  let isQwenCleoUsed = false;
  try {
    qwenCleoData = await transcribeWithQwenCleo(buffer, ext, mimeType);
    if (qwenCleoData?.text) {
      isQwenCleoUsed = true;
    }
  } catch (qwenErr: any) {
    console.warn("QwenCleo-ASR transcription step skipped:", qwenErr?.message || qwenErr);
  }

  // 2. Check for Whisper OpenAI library availability
  let whisperTranscript: string | null = null;
  let whisperSegments: any[] = [];
  let isWhisperApiUsed = false;
  const openai = getOpenAIClient();

  if (openai) {
    try {
      console.log("Whisper library detected (OPENAI_API_KEY). Transcribing audio with OpenAI Whisper (whisper-1)...");
      const audioFile = await toFile(buffer, `call_audio.${ext}`, { type: mimeType });
      // Use AbortController for OpenAI Whisper timeout of 40 seconds to prevent hanging
      const whisperController = new AbortController();
      const whisperTimeout = setTimeout(() => whisperController.abort(), 40000);

      try {
        const whisperRes: any = await openai.audio.transcriptions.create(
          {
            file: audioFile,
            model: "whisper-1",
            response_format: "verbose_json",
            timestamp_granularities: ["segment"],
            language: "ar",
            prompt: "محادثة هاتفية كول سنتر صيدليات عبداللطيف الطرشوبي بين العميل والموظف، تفريغ دقيق للهمسات وأدق الأصوات والكلمات بالعامية المصرية وأسماء الأدوية."
          },
          { signal: whisperController.signal }
        );
        clearTimeout(whisperTimeout);

        whisperTranscript = whisperRes.text || null;
        if (Array.isArray(whisperRes.segments)) {
          whisperSegments = whisperRes.segments.map((s: any) => ({
            start: s.start,
            end: s.end,
            text: s.text,
          }));
        }
        isWhisperApiUsed = true;
        console.log(`Whisper transcription succeeded (${whisperSegments.length} segments extracted).`);
      } catch (innerWhisperErr: any) {
        clearTimeout(whisperTimeout);
        const errMsg = String(innerWhisperErr?.message || innerWhisperErr);
        const isQuotaOrAuth =
          errMsg.includes("429") ||
          errMsg.includes("credits") ||
          errMsg.includes("quota") ||
          errMsg.includes("billing") ||
          errMsg.includes("401") ||
          errMsg.includes("Unauthorized") ||
          errMsg.includes("insufficient_quota");

        if (isQuotaOrAuth) {
          console.warn("OpenAI Whisper API unavailable (Quota/Credits limit reached: 429). Seamlessly utilizing Gemini Multimodal Acoustic Diarization.");
        } else {
          console.warn("Whisper verbose_json format failed, retrying with json format:", errMsg);
          try {
            const resFallback: any = await openai.audio.transcriptions.create({
              file: audioFile,
              model: "whisper-1",
              response_format: "json",
              language: "ar",
            });
            if (resFallback?.text) {
              whisperTranscript = resFallback.text;
              isWhisperApiUsed = true;
              console.log("Whisper fallback transcription succeeded.");
            }
          } catch (fErr: any) {
            console.warn("Whisper fallback attempt also failed:", fErr?.message || fErr);
          }
        }
      }
    } catch (whisperErr: any) {
      console.warn("Whisper model call encountered an issue, proceeding with high-gain neural acoustic diarization:", whisperErr?.message || whisperErr);
    }
  }

  const systemInstruction = `أنت محلل جودة مكالمات كول سنتر خبير ومحترف للغاية لصيدليات الـ عبداللطيف الطرشوبي وجروب العمل ومجهز بنظام المعالجة الصوتية فائق الدقة (Whisper-Grade Acoustic Precision). مهمتك الأساسية هي تفريغ المكالمة الهاتفية تفريغاً حرفياً شاملاً مع الإنصات لأدق الأصوات والهمسات وفصل المتحدثين بدقة متناهية وتحليل جودتها وأداء الزميل أو الزميلة.

نظام المعالجة الصوتية فائق الدقة والإنصات العميق (Whisper-Grade Acoustic Precision & Speaker Diarization):
1. التدقيق والإنصات لأدق الأصوات والهمسات (High Sensitivity to Faint Sounds & Whispers):
   - قم بالاستماع الفائق والإنصات العميق لكافة الترددات الصوتية المنخفضة وأدق النبرات، والتقاط الهمسات والردود الخافتة والمكتومة (Muffled words / Whispers) الصادرة من أي من الطرفين (مثل الردود التلقائية المقتضبة: "تمام"، "أيوه"، "حاضر"، "طب لحظة"، "يا فندم"، "ألو"، "اممم"، "معاك"، أو أسماء الأدوية والتركيزات المنطوقة بصوت منخفض جداً).
   - يُمنع منعاً باتاً إهمال أو تفويت أي صوت منطوق أو همسة مهما بلغت درجة انخفاضها أو ضعف مستواها الصوتي في التسجيل، ويجب تدوينها حرفياً في الـ transcript.
2. التفرقة الصوتية الحازمة والدقيقة بين صوت العميل والموظف (Strict Speaker Diarization):
   - فرّق بصورة دقيقة ومطلقة بين صوت العميل وصوت موظف خدمة العملاء استناداً للبصمة الصوتية (Voiceprint) وخصائص القناة:
     * موظف خدمة العملاء: يمتلك نبرة صوت احترافية واستوديو/سماعة كول سنتر، ويبدأ المكالمة بتقديم صيدليات الطرشوبي ونطق اسمه الصريح، ويوجه المحادثة لخدمة العميل وتأكيد الأصناف الدوائية.
     * العميل: المتصل من الهاتف الخارجي (غالباً ما يكون صوته متأثراً بضجيج الخلفية أو حركة السير أو خط الهاتف)، ويطلب العلاج أو يستفسر عن المنتجات.
   - في حالات تداخل الأصوات (Overlapping / Cross-talk) ومقاطعة الكلام، لا تدمج كلام الطرفين معاً مطلقاً في فقرة واحدة، بل افصل كلام العميل في مقطع مستقل وكلام الموظف في مقطع مستقل مع ضبط أجزاء الثواني الدقيقة لكل منهما.
   - تحديد المتحدث بدقة حصرية: "العميل" أو "موظف خدمة العملاء" أو "فترة صمت الموظف".

تحديد أطراف المكالمة ديناميكيًا ودون توحيد الاسم (عدم فرض اسم مسبق):
1. الزميل/الزميلة (موظف خدمة العملاء): الموظف(ة) الذي يمثل صيدليات الـ عبداللطيف الطرشوبي ويفتتح المكالمة بالترحيب وتقديم نفسه باسمه/باسمها الفعلي المسموع في الصوت (مثل: "سارة"، "ريمون"، "خديجة"، "كريم"، إلخ) دون فرض اسم افتراضي موحد. يجب كشف الاسم الحقيقي للزميل(ة) مباشرة من مقدمة المحادثة واستخدامه في كامل التحليل وتجنب الأسماء الافتراضية.
2. العميل: المتصل الآخر الذي يطلب خدمة، وله نقد لأسلوبه والتلفظ باسمه ولقبه.

قوانين صارمة وشاملة لتقييم وتحليل وتدقيق الترحيب بالعميل (greetingAnalysis):
1. الزميل(ة) (الموظف) ملزم(ة) تماماً بالترحيب بالعميل في بداية المكالمة (سواء في الجملة الافتتاحية الأولى أو أثناء الرد والترحيب بالعميل باسمه بعد أن يبدأ العميل حديثه، مثل: "أهلاً وسهلاً يا أستاذة لميس"، "أهلاً بحضرتك يا فندم"، "أهلاً وسهلاً"، "نورتنا"، إلخ).
2. الألفاظ المعتمدة للترحيب تشمل:
   - "أهلاً" ومشتقاتها ومرادفاتها الترحيبية الصريحة: "أهلاً وسهلاً"، "أهلاً وسهلاً بحضرتك"، "أهلاً بيك"، "أهلاً بيكي"، "أهلاً بحضرتك"، "يا أهلاً"، "يا هلا"، "مرحباً"، "مرحب".
   - "نورتنا"، "نورتينا"، "نورت"، "نورتوا".
   - "شرفتنا"، "شرفتينا"، "شرفت"، "شرفتونا".
3. تنبيه صارم ودقيق جداً: إذا نطق الزميل جملة ترحيب مثل "أهلاً وسهلاً يا أستاذة لميس" أو "أهلاً بحضرتك" أو أي جملة تحتوي على "أهلاً" أو "أهلاً وسهلاً":
   - يُمنع منعاً باتاً تقييم المكالمة بـ "لم يتم الترحيب"!
   - يجب تعيين isGreetingUsed كـ true بشكل قاطع ومؤكد.
   - إدراج العبارة المنطوقة (مثل "أهلاً وسهلاً" أو "أهلاً") في detectedGreetingPhrases.
   - تدوين الطابع الزمني لذكر الترحيب في greetingTimestamps.
   - تدوين النص الكامل للترحيب في greetingTextSnippet (مثل: "أهلاً وسهلاً يا أستاذة لميس").
   - كتابة تقييم إيجابي مشيد بالترحيب الراقي والمباشر بالعميلة في evaluation.
4. إذا وفقط إذا خلت المكالمة تماماً من أي لفظ أو صيغة ترحيب في البداية من الزميل، يعين isGreetingUsed كـ false والتقييم بالنص: "لم يتم الترحيب" في حقل التقييم (evaluation).

قوانين صارمة وشاملة لتقييم وتحليل وتدقيق تقديم التعاطف والدعم للعميل (empathyAnalysis):
1. الزميل(ة) (الموظف) ملزم(ة) تماماً وصراحة بتقديم التعاطف بالصوت باستخدام أحد الألفاظ المعتمدة للتعاطف عند رصد شكوى من تعب أو مرض أو طلب دواء علاجي من العميل أو في أي لحظة خلال المحادثة أو ختامها:
   - عبارات الشفاء والدعاء بالصحة: "بالشفاء"، "وبالشفاء"، "بالشفاء إن شاء الله"، "وبالشفاء إن شاء الله"، "بالشفا"، "وبالشفا"، "بالشفا إن شاء الله"، "وبالشفا إن شاء الله"، "ربنا يشفيك"، "ربنا يشفيه"، "ربنا يشفيها"، "شفاكم الله"، "طهور إن شاء الله".
   - عبارات السلامة: "ألف سلامة"، "سلامتك"، "سلامته"، "سلامتها"، "الله يسلمك"، "حمد لله على السلامة".
2. تنبيه صارم ودقيق جداً: عبارة "وبالشفاء ان شاء الله" أو "بالشفاء ان شاء الله" أو "بالشفاء" أو "بالشفا" أو "ألف سلامة" هي تعاطف صريح ومؤكد 100%! إذا نطق الزميل أياً من هذه العبارات (أو أي تصريف لها مع حروف العطف مثل "و" أو الدعاء مثل "إن شاء الله")، يجب حتماً وبشكل قاطع تعيين:
   - isEmpathyUsed كـ true حتماً.
   - إدراج العبارة المنطوقة (مثل "وبالشفاء ان شاء الله") في detectedEmpathyPhrases.
   - زيادة empathyCount بعدد مرات النطق.
   - تدوين التوقيت الزمني الدقيق في empathyTimestamps.
   - تدوين النص الملتقط في empathyTextSnippet.
   - تسجيل التقييم الإيجابي المناسب في evaluation مع الإشادة بتعاطف الزميل مع العميل.
3. يُمنع منعاً باتاً تحت أي ظرف تقييم المكالمة بـ "لم يتم التعاطف" إذا كانت هذه العبارات قد قيلت بالصوت في أي موضع من المكالمة. إذا وفقط إذا لم يتم التلفظ بأي لفظ أو صيغة تعاطف أو شفاء مطلقاً طوال المكالمة، يعين isEmpathyUsed كـ false والتقييم بالنص: "لم يتم التعاطف" في حقل التقييم (evaluation).

قوانين صارمة وشاملة لتقييم وتحليل وتدقيق عرض الخدمات والمساعدات الإضافية (furtherAssistanceAnalysis):
1. الزميل(ة) ملزم(ة) بعرض خدمات أخرى أو مساعدة إضافية في نهاية المكالمة (ولكن حصرياً بعد مراجعة الأوردر بالكامل مع العميل أو بعد ذكر الإجمالي الكلي للطلب وقبل وداع المكالمة، مثل: "أقدر أساعدك في حاجة تانية يا فندم؟").
2. إذا تم تقديم العرض في هذا التوقيت السليم والموقع المطلوب، فإن قيمة isAssistanceOffered تكون true.
3. إذا غاب هذا العرض تماماً أو جاء في غير موضعه الصحيح، يعين isAssistanceOffered كـ false والتقييم بالنص الحصري: "لم يتم عرض خدمات أخرى" في حقل التقييم (evaluation).

قوانين صارمة وشاملة لتقييم وتحليل وتدقيق لغة ختام وإنهاء المكالمة (callEndingAnalysis):
1. الوداع المقبول فقط باستخدام أحد الألفاظ التالية: "شرفتنا" أو "شرفت" أو "شكرا لاتصالك".
2. إذا لم تذكر، يعين isEndingPhraseUsed كـ false والتقييم بالنص الحصري: "لم يتم إنهاء المكالمة بالصيغة المطلوبة" في حقل التقييم.

قوانين صارمة لمراجعة الألفاظ غير الاحترافية للزميل(ة) فقط:
1. تتبع الكلمات: (هيجي، مليني، ادي، هنحط، هيعبي، ايه، اركن) وتحقق من تكرارها من الزميل فقط.

قوانين صارمة وشاملة لتقييم وتحليل وتدقيق اللازمات اللفظية وتكرار الكلمات المتكرر للزملاء (verbalTicsAnalysis):
- تتبع ورصد اللازمات اللفظية والكلمات والتعبيرات غير المفيدة المكررة بشكل مفرط في حديث الزميل(ة) (مثل: مكررة 3 مرات أو أكثر في كامل المكالمة بشكل يمثل لقمة حوارية أو لازمة لفظية معتادة مثل "تمام"، "تمام يا فندم"، "فاهم حضرتك"، "معايا"، "معاك"، "يعنى"، "مظبوط"، إلخ).
- سجل الكلمة ومعدل حضورها/تكرارها وطوابعها الزمنية للبدء ومقترح التبديل لمساعدتها على زيادة الثراء اللفظي.

قوانين صارمة وشاملة لتقييم وتحليل وتدقيق نبرة صوت الزملاء (agentToneAnalysis):
1. مراجعة ابتسام وبشاشة الموظفة من نبرة صوتها بالعامية المصرية وبشرط حصر النواقص النبرية ضمن العيوب الثلاثة الحصرية فقط وذكر ذلك في "smileEvaluation".
2. الملاحظة الدقيقة وتصنيف قصور النبرة الحصري:
   - يجب حصر أي قصور أو ملاحظات سلبية في نبرة أو أداء صوت الزميل(ة) في أحد هذه الجوانب الثلاثة فقط وحصرياً دون غيرها:
     * "ينقصها الابتسامة وبها تردد أحياناً" (أو "ينقصها الابتسامة وبها تردد")
     * "ينقصها التفاعل"
     * "ينقصها الحماس"
3. تخصيص السمات الملازمة للنبرة (detectedTraits) بشكل فردي دون توحيد:
   - في حالة رصد عيوب أو تراجع في الأداء النبري (مثل غياب الابتسامة أو وجود تردد عرضي في الحديث)، يجب حتماً ولزاماً استخدام وتصنيف السمات السلبية من الخيارات المحددة فقط: ("ينقصها الابتسامة وبها تردد أحياناً"، "ينقصها الابتسامة وبها تردد"، "ينقصها التفاعل"، "ينقصها الحماس").
   - في حالة تميز النبرة وسلامتها من أي عيب، أضف سمات إيجابية مستحقة مثل: ("بشوشة ومرحبة", "واثقة وسريعة البديهة", "مستقرة وانسيابية", "تفاعل ودود ومحترف").
4. التقييم العادل والموضوعي المستقل لنبرة الصوت (score):
   - قيم نبرة الصوت من 10 بناءً على الرصد الواقعي والسمات الإيجابية أو السلبيات المكتشفة في الصوت، واخصم نقاطاً بشكل عادل وتدريجي عن كل عيب ملحوظ (مثل خصم نقاط إذا كانت النبرة ينقصها الابتسامة وبها تردد أحياناً).
5. قواعد المعايرة القياسية للمكالمات (Benchmark Call Calibration Guidelines):
   - تُعتبر هذه المكالمة معياراً مرجعياً قياسياً (BENCHMARK) لتدقيق الجودة في صيدليات عبداللطيف الطرشوبي.
   - معايرة النبرة المرجعية: عند رصد غياب البشاشة والابتسامة في الصوت مع وجود تردد عارض في بعض الردود، تُصنف النبرة بدقة: hasSmile = false، و smileEvaluation توضح غياب الابتسامة ووجود التردد في الصوت بالعامية المصرية، و detectedTraits تتضمن "ينقصها الابتسامة وبها تردد أحياناً".

قوانين صارمة وشاملة للتفرقة الحاسمة بين الهولد (موسيقى انتظار عالية) وفترات الصمت (هدوء تام وسكوت فقط) (Distinguishing Hold vs Silence):
1. التفرقة الحاسمة بين الهولد والصمت بناءً على الصوت:
   - الهولد (Hold): يتم التعرف عليه وتصنيفه عند سماع موسيقى عالية أو نغمة انتظار متكررة وواضحة (Music on hold / Loud music / Hold ringtone)، أو عندما يستأذن الموظف العميل صراحة للبحث ويتم تشغيل موسيقى الانتظار العالية. يسجل الهولد حصرياً في (holdTimeSummary) ويُمنع منعاً باتاً تسجيله كصمت للموظف.
   - الصمت (Silence / Dead Air): يكون هدوءاً وسكوتاً بين أطراف المحادثة الحقيقيين (الزميل والعميل)، وخالياً تماماً من أي موسيقى هولد عالية. يسجل الصمت حصرياً في (agentSilenceSummary).

2. قاعدة القياس الصارمة لفترات الصمت بين المتحدثين الحقيقيين (الزميل والعميل حصراً، وتجاهل أصوات الخلفية تماماً):
   - يتم احتساب الصمت فقط وحصرياً بالاستناد لأطراف الحوار الفعليين: الزميل (موظف خدمة العملاء) والعميل فقط لا غير.
   - يُمنع منعاً باتاً الخلط بين الصمت وأصوات الخلفية (Background Noise / Chatter / Street / Office sounds): حتى لو كان هناك ضجيج، أو حركة في الشارع، أو صدى، أو أصوات أشخاص آخرين في الخلفية، فإن هذا لا يلغي فترة الصمت طالما أن الزميل والعميل كلاهما ساكت ولا يتحدث.
   - معادلة قياس الصمت الدقيقة:
     * تبدأ فترة الصمت ("timeStart") فوراً من الطابع الزمني لنهاية آخر كلمة نطق بها المتحدث الفعلي (الزميل أو العميل).
     * تنتهي فترة الصمت ("timeEnd") عند الطابع الزمني لبدء أول كلمة ينطق بها المتحدث الفعلي (الزميل أو العميل).
     * مدة الصمت ("duration"): الفارق الزمني بالثواني بين نهاية آخر كلمة منطوقة من أحدهما وبداية أول كلمة منطوقة من أحدهما.
   - كل فترة صمت تدون في silenceSegments بوضوح:
     * "timeStart": وقت نهاية آخر كلمة للمتحدث الفعلي السابق (MM:SS).
     * "timeEnd": وقت بداية أول كلمة للمتحدث الفعلي اللاحق (MM:SS).
     * "duration": مدة الصمت بالثواني.
     * "fromSpeaker": "العميل" أو "موظف خدمة العملاء" (من قال آخر كلمة قبل الصمت).
     * "toSpeaker": "العميل" أو "موظف خدمة العملاء" (من بدأ بالكلام بعد الصمت).
     * "description": وصف واضح يؤكد الصمت بين كلام الزميل والعميل وتجاهل أي ضوضاء خلفية (مثال: "سكوت تام بين الطرفين من نهاية آخر كلمة للموظف عند 00:22 إلى أول كلمة للعميل عند 00:27").

3. تسجيل الهولد في holdTimeSummary:
   - أي مقطع به موسيقى عالية صريحة للانتظار يُسجل في holdTimeSummary مع توضيح وقت البدء والانتهاء وذكر خاصية الصوت: "موسيقى انتظار عالية".

يجب تقديم النتيجة حصراً بصيغة JSON متوافقة تماماً مع الهيكل المطلوب.`;

  let promptText = `يرجى تفريغ الملف الصوتي بدقة فائقة بالغة للغاية مع تفعيل نظام الإنصات فائق الدقة (Whisper-Grade Acoustic Precision) لاستخلاص أدق الهمسات وردود الزميل المكتومة أو الخافتة وأصوات التأكيد المقتضبة، والتفرقة الصوتية الحازمة بين صوت العميل وموظف خدمة العملاء وفصل التداخل الصوتي بالكامل دون تقصير أو كسل أو حذف.
من فضلك التزم بكافة القواعد الصارمة المذكورة في التعليمات لتحليل المكالمة والترحيب والتعاطف والوداع وضبط فترات الانتظار (الهولد)، واستخراج الألفاظ غير الاحترافية المحددة للزميل فقط، ورصد وتحليل اللازمات اللفظية وتكرار الكلمات المتكررة (verbalTicsAnalysis) للزميل.
قاعدة حاسمة ومؤكدة لتحليل الصمت (الهدوء): يتم تحديد الصمت فقط بالاستناد إلى حديث الزميل والعميل حصراً، مع عدم الخلط نهائياً بأي أصوات أو ضجيج في الخلفية. وتُقاس فترة الصمت تحديداً من نهاية آخر كلمة قالها الزميل أو العميل حتى بداية أول كلمة قالها الزميل أو العميل.
تأكد من تحديد المتحدثين بدقة: 'العميل' أو 'موظف خدمة العملاء' أو 'فترة صمت الموظف'.`;

  if (qwenCleoData?.text) {
    promptText += `\n\n[بيانات التفريغ الصوتي فائق الدقة المخصص للعامية المصرية والتبديل اللغوي عبر مكتبة وموديل QwenCleo-ASR (mohammedaly22/QwenCleo-ASR)]:\n"${qwenCleoData.text}"\n\nتوجيه إلزامي حاسم: استعن بنص تفريغ QwenCleo-ASR أعلاه (المتخصص بأعلى درجات الدقة في العامية المصرية ومفردات اللهجة وأسماء الأدوية والمصطلحات الصيدلانية) كمرجع أساسي ودقيق للألفاظ المنطوقة، مع الاستماع المباشر للملف الصوتي المرفق للفصل الصوتي الصارم بين المتحدثين، ورصد فترات الصمت وفقاً لحديث الطرفين حصراً.\n`;
  }

  if (whisperTranscript) {
    promptText += `\n\n[بيانات التفريغ الصوتي فائق الحساسية المُستخرج بواسطة مكتبة وموديل Whisper (whisper-1)]:\n"${whisperTranscript}"\n\nمقاطع Whisper الزمنية عالية الدقة:\n${JSON.stringify(whisperSegments.slice(0, 35), null, 2)}\n\nتوجيه إلزامي حاسم: استعن بتفريغ Whisper الصوتي عالي الحساسية أعلاه مع الاستماع المباشر للملف الصوتي المرفق للفصل الصوتي الدقيق (Diarization) بين صوت العميل وصوت موظف خدمة العملاء، ونسب كل جملة أو همسة أو صوت خافت إلى متحدثه الصحيح بدقة متناهية، ثم استخراج كافة معايير جودة المكالمة الصارمة.\n`;
  }

  promptText += `\n\nيجب أن تكون المخرجات متوافقة مع الهيكل التالي بشكل صارم وبدون أي خروج عنه:
{
  "transcript": [
    {
      "speaker": "العميل" | "موظف خدمة العملاء" | "فترة صمت الموظف",
      "text": "تفريغ الكلام بدقة بالعامية المصرية حرفياً وبكل تفصيل، أو وصف الصمت",
      "timeStart": "الطابع الزمني للبدء بصيغة MM:SS (مثال: 00:04)",
      "timeEnd": "الطابع الزمني للانتهاء بصيغة MM:SS (مثال: 00:12)",
      "duration": مدة هذا المقطع بالثواني كاملاً (عدد صحيح)
    }
  ],
  "agentSilenceSummary": {
    "totalSilenceSeconds": مجموع ثواني صمت الموظف بالكامل (هدوء فقط بدون موسيقى) (عدد صحيح),
    "silenceCount": عدد فترات الصمت المكتشفة للموظف (عدد صحيح),
    "silenceRatio": نسبة صمت الموظف المئوية مقارنة بمدة المكالمة الإجمالية (عدد صحيح أو عشري),
    "silenceSegments": [
      {
        "timeStart": "الطابع الزمني لبداية الصمت (نهاية آخر كلمة للمتحدث السابق) بصيغة MM:SS",
        "timeEnd": "الطابع الزمني لنهاية الصمت (بداية أول كلمة للمتحدث اللاحق) بصيغة MM:SS",
        "duration": مدة فترة الصمت بالثواني (عدد صحيح),
        "fromSpeaker": "العميل" | "موظف خدمة العملاء",
        "toSpeaker": "العميل" | "موظف خدمة العملاء",
        "description": "وصف دقيق يوضح هدوء وسكون من آخر كلمة لمن عند كذا إلى أول كلمة لمن عند كذا بالعامية المصرية"
      }
    ]
  },
  "customerNameAnalysis": {
    "customerNameDetected": "اسم العميل الشخصي الفعلي المكتشف في المكالمة دون ألقاب احترام",
    "isMentionedByAgent": true / false,
    "mentionCount": عدد المرات التي ذكر فيها الموظف اسم العميل,
    "mentionsTimestamps": ["الطوابع الزمنية لذكر الاسم بصيغة MM:SS"]
  },
  "customerTitleAnalysis": {
    "titleDetected": "اللقب الفعلي المكتشف للعميل (مثل دكتور، مستشار، مهندس، أستاذ، شيخ، حاج) أو 'لم يذكر' إن غاب",
    "isTitleUsedByAgent": true / false,
    "titleTextSnippet": "نص الجملة أو العبارة الفعلية التي ذكر فيها الزميل لقب العميل المكتشف لندائه باحترافية",
    "titleMentionCount": عدد المرات التي ذكر فيها اللقب,
    "titleMentionsTimestamps": ["الطوابع الزمنية الدقيقة لذكر اللقب بصيغة MM:SS"],
    "evaluation": "التقييم الفني لتقدير الزميل لألقاب العميل المهنية والتشريفية مع النصيحة والبديل بالعامية المصرية"
  },
  "holdTimeSummary": {
    "totalHoldSeconds": إجمالي وقت الانتظار الهولد المصحوب بموسيقى عالية بالثواني كاملاً,
    "holdCount": عدد فترات وضع المكالمة على الهولد مع موسيقى,
    "holdSegments": [
      {
        "timeStart": "الطابع الزمني للبدء بصيغة MM:SS",
        "timeEnd": "الطابع الزمني للانتهاء بصيغة MM:SS",
        "duration": مدة الانتظار بالثواني,
        "hasLoudMusic": true,
        "audioCharacteristic": "موسيقى انتظار عالية"
      }
    ]
  },
  "greetingAnalysis": {
    "isGreetingUsed": true / false,
    "detectedGreetingPhrases": ["عبارات الترحيب المكتشفة من القائمة الحصرية فقط"],
    "greetingTimestamps": ["الطوابع الزمنية لذكر عبارة الترحيب بصيغة MM:SS"],
    "greetingTextSnippet": "نص الترحيب والتقديم المباشر الفعلي الذي قاله الزميل في بداية المكالمة",
    "evaluation": "تقييم الترحيب والمظهر الاحترافي بالعامية المصرية مع مقترحات التحسين"
  },
  "empathyAnalysis": {
    "isEmpathyUsed": true / false,
    "detectedEmpathyPhrases": ["عبارات التعاطف المكتشفة من القائمة الحصرية فقط"],
    "empathyCount": 1,
    "empathyTimestamps": ["الطوابع الزمنية لذكر عبارة التعاطف بصيغة MM:SS"],
    "empathyTextSnippet": "نص جملة التعاطف الفعلي من المكالمة",
    "evaluation": "التقييم الفني لتعاطف الزميل"
  },
  "furtherAssistanceAnalysis": {
    "isAssistanceOffered": true / false,
    "detectedAssistancePhrases": ["عبارات عرض خدمات أخرى أو مساعدة إضافية"],
    "assistanceTextSnippet": "نص جملة عرض المساعدة الإضافية",
    "evaluation": "التقييم الفني لعرض الخدمات الأخرى"
  },
  "unprofessionalWordsAnalysis": {
    "hasUnprofessionalWords": true / false,
    "totalUnprofessionalWordsCount": إجمالي عدد الكلمات غير الاحترافية المكتشفة للزميل فقط,
    "detectedWords": [
      {
        "word": "اسم الكلمة غير الاحترافية المكتشفة",
        "count": عدد مرات تكرارها بواسطة الزميل,
        "timestamps": ["الطوابع الزمنية الدقيقة لكل منها بصيغة MM:SS"]
      }
    ],
    "evaluation": "التقييم الفني لاستخدام الزميل للألفاظ والعبارات غير الاحترافية وتقديم التوجيه والبدائل المهنية"
  },
  "callEndingAnalysis": {
    "isEndingPhraseUsed": true / false,
    "detectedEndingPhrases": ["عبارات إنهاء المكالمة والوداع المكتشفة من القائمة الحصرية فقط"],
    "endingTextSnippet": "نص الجملة الفعلي لإنهاء المكالمة والوداع صادر من الزميل",
    "evaluation": "التقييم الفني لجودة ختام وتوديع المكالمة بالعامية المصرية، ويجب أن يكون اللفظ الحصري 'لم يتم إنهاء المكالمة بالصيغة المطلوبة' في حال عدم كشف الكلمات المحددة"
  },
  "agentApologyAnalysis": {
    "isApologyNeeded": true / false,
    "isApologyUsedByAgent": true / false,
    "apologyMentionCount": عدد مرات تكرار الاعتذار,
    "apologyTimestamps": ["طوابع الاعتذار بصيغة MM:SS"],
    "apologyTextSnippet": "نص الجملة الفعلي للاعتذار",
    "evaluation": "التقييم الفني لاعتذار الزميل بالعامية المصرية"
  },
  "agentToneAnalysis": {
    "introductionSummary": "خلاصة نقد نبرة الصوت وحضور الابتسامة بالافتتاحية بالعامية المصرية",
    "callSummary": "خلاصة نبرة الموظفة وتفاعلها وبشاشتها طوال المكالمة بالعامية المصرية",
    "hasSmile": true / false,
    "smileEvaluation": "نقد تفصيلي لمدى ابتسام وبشاشة الموظفة من نبرة صوتها بالعامية المصرية وبشرط حصر النواقص النبرية ضمن العيوب الثلاثة الحصرية فقط",
    "detectedTraits": ["ينقصها الابتسامة وبها تردد أحياناً", "ينقصها التفاعل", "ينقصها الحماس"],
    "score": 8
  },
  "isBenchmark": true,
  "benchmarkNotes": "ملاحظات المعايرة القياسية للمكالمة المرجعية",
  "verbalTicsAnalysis": {
    "hasVerbalTics": true / false,
    "detectedTics": [
      {
        "word": "اللازمة اللفظية المحددة بالعامية مثل تمام أو حضرتك أو يا فندم",
        "count": عدد مرات تكرارها,
        "timestamps": ["الطوابع الزمنية الدقيقة للتكرار في المكالمة"]
      }
    ],
    "evaluation": "التقييم الفني بالعامية المصرية لأسلوب التكرار اللفظي وكيفية تجنب مرادفات الحشو اللفظي"
  }
}`;

  // Call the correct SDK model and parameters
  try {
    const response = await generateContentWithRetry({
      model: "gemini-3.5-flash",
      contents: [
        {
          inlineData: {
            mimeType,
            data: audioBytes,
          },
        },
        {
          text: promptText,
        },
      ],
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        thinkingConfig: {
          thinkingLevel: ThinkingLevel.LOW,
        },
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            transcript: {
              type: Type.ARRAY,
              description: "أجزاء تفريغ المكالمة بالترتيب الزمني متضمنة فترات الصمت.",
              items: {
                type: Type.OBJECT,
                properties: {
                  speaker: {
                    type: Type.STRING,
                    description: "المتحدث في هذا الجزء: 'العميل' أو 'موظف خدمة العملاء' أو 'فترة صمت الموظف'",
                  },
                  text: {
                    type: Type.STRING,
                    description: "التفريغ الحرفي الكامل والصارم كلمة بكلمة بالعامية المصرية دون أي تلخيص أو تفويت لأي لفظ أو رد مثل تمام، يا فندم، حاضر، نعم، مع السلامة، إلخ، أو وصف الصوت والصمت بدقة.",
                  },
                  timeStart: {
                    type: Type.STRING,
                    description: "وقت البدء بصيغة MM:SS",
                  },
                  timeEnd: {
                    type: Type.STRING,
                    description: "وقت الانتهاء بصيغة MM:SS",
                  },
                  duration: {
                    type: Type.INTEGER,
                    description: "المدة بالثواني",
                  },
                },
                required: ["speaker", "text", "timeStart", "timeEnd", "duration"],
              },
            },
            agentSilenceSummary: {
              type: Type.OBJECT,
              description: "ملخص تحليلي لفترات صمت موظف خدمة العملاء (ملاحظة حاسمة: يجب استبعاد أي فترات هولد أو انتظار مبرر تماماً من هذا الملخص ومن فترات الصمت لمنع الازدواجية والتقييم السلبي الخاطئ للموظف).",
              properties: {
                totalSilenceSeconds: {
                  type: Type.INTEGER,
                  description: "إجمالي ثواني الصمت (باستثناء فترات الهولد)",
                },
                silenceCount: {
                  type: Type.INTEGER,
                  description: "إجمالي عدد فترات الصمت المكتشفة (باستثناء فترات الهولد)",
                },
                silenceRatio: {
                  type: Type.NUMBER,
                  description: "نسبة الصمت المئوية من إجمالي عمر المكالمة (باستثناء فترات الهولد)",
                },
                silenceSegments: {
                  type: Type.ARRAY,
                  description: "تفاصيل فترات الصمت والسكوت غير المبرر المكتشفة في المكالمة (يجب استبعاد فترات الهولد تماماً من هنا).",
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      timeStart: {
                        type: Type.STRING,
                        description: "الطابع الزمني لنهاية آخر كلمة قالها الزميل أو العميل بصيغة MM:SS (تجاهل أي ضوضاء في الخلفية)",
                      },
                      timeEnd: {
                        type: Type.STRING,
                        description: "الطابع الزمني لبدء أول كلمة قالها الزميل أو العميل بصيغة MM:SS (تجاهل أي ضوضاء في الخلفية)",
                      },
                      duration: {
                        type: Type.INTEGER,
                        description: "مدة الصمت بالثواني كاملاً",
                      },
                      fromSpeaker: {
                        type: Type.STRING,
                        description: "المتحدث السابق قبل فترة الصمت ('العميل' أو 'موظف خدمة العملاء')",
                      },
                      toSpeaker: {
                        type: Type.STRING,
                        description: "المتحدث اللاحق بعد فترة الصمت ('العميل' أو 'موظف خدمة العملاء')",
                      },
                      description: {
                        type: Type.STRING,
                        description: "وصف دقيق بالعامية المصرية يوضح من آخر كلمة لمن عند كذا إلى أول كلمة لمن عند كذا",
                      },
                    },
                    required: ["timeStart", "timeEnd", "duration", "fromSpeaker", "toSpeaker", "description"],
                  },
                },
              },
              required: ["totalSilenceSeconds", "silenceCount", "silenceRatio", "silenceSegments"],
            },
            customerNameAnalysis: {
              type: Type.OBJECT,
              description: "تحليل اسم العميل وذكر الموظف له.",
              properties: {
                customerNameDetected: {
                  type: Type.STRING,
                  description: "الاسم المكتشف للعميل أو فارغ في حال عدم ذكره أبداً.",
                },
                isMentionedByAgent: {
                  type: Type.BOOLEAN,
                  description: "هل تم ذكره بواسطة الموظف أم لا",
                },
                mentionCount: {
                  type: Type.INTEGER,
                  description: "إجمالي المرات التي نطق فيها الموظف اسم العميل",
                },
                mentionsTimestamps: {
                  type: Type.ARRAY,
                  description: "طوابع وقت ذكر الاسم بواسطة الموظف بصيغة MM:SS",
                  items: { type: Type.STRING },
                },
              },
              required: ["customerNameDetected", "isMentionedByAgent", "mentionCount", "mentionsTimestamps"],
            },
            customerTitleAnalysis: {
              type: Type.OBJECT,
              description: "تحليل ألقاب العميل المهنية أو الفخرية (مثل دكتور / مستشار / مهندس / أستاذ / شيخ / إلخ).",
              properties: {
                titleDetected: {
                  type: Type.STRING,
                  description: "اللقب المهني/الفخري المكتشف للعميل صراحة في المكالمة، أو 'لم يذكر' إذا لم تُكشف أي ألقاب.",
                },
                isTitleUsedByAgent: {
                  type: Type.BOOLEAN,
                  description: "هل استخدم الزميل لقب العميل المناسب وناداه به أم تجاوزه؟",
                },
                titleMentionCount: {
                  type: Type.INTEGER,
                  description: "عدد مرات ذكر اللقب الفعلي المكتشف بواسطة الموظف.",
                },
                titleMentionsTimestamps: {
                  type: Type.ARRAY,
                  description: "الطوابع الزمنية الدقيقة لذكر اللقب بصيغة MM:SS",
                  items: { type: Type.STRING },
                },
                titleTextSnippet: {
                  type: Type.STRING,
                  description: "العبارة أو السطر الفعلي الذي تلفظ فيه الزميل بلقب العميل.",
                },
                evaluation: {
                  type: Type.STRING,
                  description: "التقييم الفني لجاهزية ولباقة ولطف الزميل في تقدير العميل بألقابه الخاصة بالعامية المصرية.",
                },
              },
              required: ["titleDetected", "isTitleUsedByAgent", "titleMentionCount", "titleMentionsTimestamps", "titleTextSnippet", "evaluation"],
            },
            holdTimeSummary: {
              type: Type.OBJECT,
              description: "تحليل واحتساب فترات وقت الهولد (الانتظار) خلال المكالمة والمميزة بوجود موسيقى انتظار عالية أو نغمة صريحة.",
              properties: {
                totalHoldSeconds: {
                  type: Type.INTEGER,
                  description: "إجمالي ثواني الانتظار (الهولد) المصحوبة بموسيقى عالية في المكالمة.",
                },
                holdCount: {
                  type: Type.INTEGER,
                  description: "عدد مرات وضع العميل على وضع الانتظار (الهولد) مع سماع موسيقى انتظار.",
                },
                holdSegments: {
                  type: Type.ARRAY,
                  description: "تفاصيل مقاطع الانتظار (الهولد المصحوب بموسيقى عالية).",
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      timeStart: { type: Type.STRING, description: "وقت البدء بصيغة MM:SS" },
                      timeEnd: { type: Type.STRING, description: "وقت الانتهاء بصيغة MM:SS" },
                      duration: { type: Type.INTEGER, description: "المدة بالثواني" },
                      hasLoudMusic: { type: Type.BOOLEAN, description: "هل تصاحبها موسيقى عالية أو نغمة انتظار (true دائما للهولد)" },
                      audioCharacteristic: { type: Type.STRING, description: "وصف الطابع الصوتي مثل: 'موسيقى انتظار عالية واضحة'" },
                    },
                    required: ["timeStart", "timeEnd", "duration"],
                  },
                },
              },
              required: ["totalHoldSeconds", "holdCount", "holdSegments"],
            },
            greetingAnalysis: {
              type: Type.OBJECT,
              description: "مراجعة وتقييم ترحيب الزميل بالعميل في مقدمة وبداية المكالمة وفق قوانين صارمة.",
              properties: {
                isGreetingUsed: {
                  type: Type.BOOLEAN,
                  description: "تكون true حتماً إذا استخدم الزميل عبارات الترحيب مثل (أهلاً، أهلاً وسهلاً، أهلاً بحضرتك، نورتنا، شرفتنا) وتكون false فقط في حال عدم الترحيب بالعميل نهائياً.",
                },
                detectedGreetingPhrases: {
                  type: Type.ARRAY,
                  description: "ألفاظ وعبارات الترحيب المكتشفة (مثل: 'أهلاً وسهلاً'، 'أهلاً بحضرتك')، وتكون فارغة [] إذا لم تستخدم.",
                  items: { type: Type.STRING },
                },
                greetingTimestamps: {
                  type: Type.ARRAY,
                  description: "الطوابع الزمنية الدقيقة لذكر عبارات الترحيب في المكالمة بصيغة MM:SS، وتكون [] فارغة إذا لم تذكر.",
                  items: { type: Type.STRING },
                },
                greetingTextSnippet: {
                  type: Type.STRING,
                  description: "نص الترحيب والتقديم المباشر الفعلي الذي قاله الزميل في بداية المكالمة (مثل: 'أهلاً وسهلاً يا أستاذة لميس').",
                },
                evaluation: {
                  type: Type.STRING,
                  description: "التقييم الفني لجودة وبشاشة الترحيب بالعامية المصرية مع الإشادة بحسن الاستقبال، ويكون بالنص 'لم يتم الترحيب' فقط إذا غابت عبارات الترحيب تماماً.",
                },
              },
              required: ["isGreetingUsed", "detectedGreetingPhrases", "greetingTimestamps", "greetingTextSnippet", "evaluation"],
            },
            empathyAnalysis: {
              type: Type.OBJECT,
              description: "مراجعة وتقييم تعاطف الزميل مع العميل خلال المكالمة بدقة فائقة.",
              properties: {
                isEmpathyUsed: {
                  type: Type.BOOLEAN,
                  description: "تكون true حتماً إذا استخدم الزميل عبارات الشفاء والدعاء مثل: (وبالشفاء ان شاء الله، بالشفاء، بالشفا، ألف سلامة، سلامتك) وتكون false فقط في حالة عدم نطق أي منها.",
                },
                detectedEmpathyPhrases: {
                  type: Type.ARRAY,
                  description: "عبارات التعاطف المكتشفة نصياً (مثل: 'وبالشفاء ان شاء الله'، 'ألف سلامة'، 'بالشفا')، وتكون [] فارغة إذا لم تستخدم.",
                  items: { type: Type.STRING },
                },
                empathyCount: {
                  type: Type.INTEGER,
                  description: "عدد مرات نطق عبارات التعاطف والدعاء بالشفاء أو السلامة في المحادثة من الزميل.",
                },
                empathyTimestamps: {
                  type: Type.ARRAY,
                  description: "الطوابع الزمنية الدقيقة لذكر عبارات التعاطف بصيغة MM:SS",
                  items: { type: Type.STRING },
                },
                empathyTextSnippet: {
                  type: Type.STRING,
                  description: "نص العبارة التي قيل فيها التعاطف أو الدعاء بالشفاء مع العميل.",
                },
                evaluation: {
                  type: Type.STRING,
                  description: "التقييم الفني لجودة التعاطف بالعامية المصرية مع الإشادة بحضور الدعاء بالشفاء أو السلامة، ويكون اللفظ 'لم يتم التعاطف' فقط في حال الغياب التام لعبارات التعاطف.",
                },
              },
              required: ["isEmpathyUsed", "detectedEmpathyPhrases", "empathyCount", "empathyTimestamps", "empathyTextSnippet", "evaluation"],
            },
            furtherAssistanceAnalysis: {
              type: Type.OBJECT,
              description: "مراجعة وتقييم عرض خدمات أخرى أو مساعدة إضافية قبل إنهاء المكالمة (على أن يُقدّم العرض بعد مراجعة الأوردر أو بعد ذكر الإجمالي للطلب).",
              properties: {
                isAssistanceOffered: {
                  type: Type.BOOLEAN,
                  description: "يجب أن تكون true فقط إذا عرض الزميل خدمات أخرى أو مساعدة إضافية (مثل: أقدر أساعدك في حاجة تانية؟) بعد مراجعة الأوردر للعميل أو بعد ذكر الإجمالي للطلب وقبل الإنهاء، وتكون false بخلاف ذلك.",
                },
                detectedAssistancePhrases: {
                  type: Type.ARRAY,
                  description: "العبارات أو الألفاظ المحددة المكتشفة لعرض المساعدة الإضافية في هذا الموضع الصحيح.",
                  items: { type: Type.STRING },
                },
                assistanceTextSnippet: {
                  type: Type.STRING,
                  description: "نص الجملة الفعلي الملتقط الذي تفوّه به الزميل لعرض خدمات أخرى.",
                },
                evaluation: {
                  type: Type.STRING,
                  description: "التقييم والتعليق الفني لعرض الخدمات الأخرى بالعامية المصرية، مع وجوب استخدام النص الحصري 'لم يتم عرض خدمات أخرى' في حال عدم تقديم العرض في الموضع السليم.",
                },
              },
              required: ["isAssistanceOffered", "detectedAssistancePhrases", "assistanceTextSnippet", "evaluation"],
            },
            unprofessionalWordsAnalysis: {
              type: Type.OBJECT,
              description: "تحليل وتتبع الألفاظ غير الاحترافية المحددة للزميل (الموظف) فقط واستبعاد تماماً أي كلام صادر من العميل.",
              properties: {
                hasUnprofessionalWords: {
                  type: Type.BOOLEAN,
                  description: "هل استخدم الزميل (وليس العميل) أي لفظ غير احترافي من القائمة المخصصة؟",
                },
                totalUnprofessionalWordsCount: {
                  type: Type.INTEGER,
                  description: "إجمالي عدد الألفاظ غير الاحترافية الموجهة من الزميل (الموظف) فقط في المكالمة (مع استثناء العميل تماماً).",
                },
                detectedWords: {
                  type: Type.ARRAY,
                  description: "تفاصيل الكلمات غير الاحترافية المكتشفة من كلام الزميل فقط.",
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      word: { type: Type.STRING, description: "الكلمة غير الاحترافية المكتشفة" },
                      count: { type: Type.INTEGER, description: "عدد مرات تكرارها من قبل الزميل فقط" },
                      timestamps: {
                        type: Type.ARRAY,
                        description: "الطوابع الزمنية للتلفظ بكل كلمة من قبل الزميل فقط بصيغة MM:SS",
                        items: { type: Type.STRING },
                      },
                    },
                    required: ["word", "count", "timestamps"],
                  },
                },
                evaluation: {
                  type: Type.STRING,
                  description: "التقييم الفني لأسلوب حوار الزميل الحصري والبدائل المقترحة له بالعامية المصرية.",
                },
              },
              required: ["hasUnprofessionalWords", "totalUnprofessionalWordsCount", "detectedWords", "evaluation"],
            },
            callEndingAnalysis: {
              type: Type.OBJECT,
              description: "مراجعة وتقييم قول الزميل عند الإنهاء بكلمة: شرفتنا، شرفت، أو شكرا لاتصالك.",
              properties: {
                isEndingPhraseUsed: {
                  type: Type.BOOLEAN,
                  description: "يجب أن تكون true فقط وحصرياً إذا استخدم الزميل عند الإنهاء لفظ (شرفتنا) أو (شرفت) أو (شكرا لاتصالك) وعكس ذلك تكون false حتماً.",
                },
                detectedEndingPhrases: {
                  type: Type.ARRAY,
                  description: "الألفاظ المكتشفة صراحة للوداع والإنهاء من القائمة الثلاثية حصرياً، وتكون فارغة [] عند غيابها.",
                  items: { type: Type.STRING },
                },
                endingTextSnippet: {
                  type: Type.STRING,
                  description: "النص الفعلي الملتقط للوداع وإنهاء المكالمة بصوت ونطق الزميل في نهاية المكالمة.",
                },
                evaluation: {
                  type: Type.STRING,
                  description: "التقييم الفني لإنهاء المكالمة بالعامية المصرية، ويجب أن يكون اللفظ الحصري 'لم يتم إنهاء المكالمة بالصيغة المطلوبة' in حال غياب الألفاظ الثلاثة المحددة.",
                },
              },
              required: ["isEndingPhraseUsed", "detectedEndingPhrases", "endingTextSnippet", "evaluation"],
            },
            agentApologyAnalysis: {
              type: Type.OBJECT,
              description: "تحليل ومطالعة اعتذار الزميل في المكالمة وتواجد كلمات مثل آسف، بعتذر، إلخ.",
              properties: {
                isApologyNeeded: {
                  type: Type.BOOLEAN,
                  description: "هل كان الموقف في المكالمة يتطلب اعتذاراً أم لا؟",
                },
                isApologyUsedByAgent: {
                  type: Type.BOOLEAN,
                  description: "هل بادر الزميل بتقديم الاعتذار فعلاً؟",
                },
                apologyMentionCount: {
                  type: Type.INTEGER,
                  description: "عدد مرات نطق الاعتذار الصريح في المكالمة من الزميل.",
                },
                apologyTimestamps: {
                  type: Type.ARRAY,
                  description: "الطوابع الزمنية الدقيقة لذكر الاعتذارات بصيغة MM:SS",
                  items: { type: Type.STRING },
                },
                apologyTextSnippet: {
                  type: Type.STRING,
                  description: "العبارة أو السطر الفعلي الملتقط الذي يحوي الاعتذار.",
                },
                evaluation: {
                  type: Type.STRING,
                  description: "الالتقاط والتحليل الفني بالعامية المصرية لاستجابة ولباقة الزميل وجودة اعتذاره.",
                },
              },
              required: ["isApologyNeeded", "isApologyUsedByAgent", "apologyMentionCount", "apologyTimestamps", "apologyTextSnippet", "evaluation"],
            },
            agentToneAnalysis: {
              type: Type.OBJECT,
              description: "التحليل والتدقيق الذكي الملخص لنبرة صوت الزميل.",
              properties: {
                introductionSummary: {
                  type: Type.STRING,
                  description: "خلاصة نبرة الصوت في المقدمة والافتتاحية بالعامية المصرية",
                },
                callSummary: {
                  type: Type.STRING,
                  description: "خلاصة نبرة الصوت وتفاعل الموظف خلال المكالمة بالعامية المصرية",
                },
                hasSmile: {
                  type: Type.BOOLEAN,
                  description: "هل نبرة الصوت بها ابتسامة وبشاشة أم لا (مبتسمة / غير مبتسمة)",
                },
                smileEvaluation: {
                  type: Type.STRING,
                  description: "تعليق وتقييم صريح لحضور أو غياب البشاشة والابتسامة بالعامية المصرية",
                },
                detectedTraits: {
                  type: Type.ARRAY,
                  description: "قائمة الكلمات أو السمات المكتشفة التي تصف نبرة الموظف. في حالة وجود تراجع أو عيوب في الأداء، يجب حتماً الاختيار فقط وحصرياً من بين هذه السمات السلبية المحددة: ('ينقصها الابتسامة وبها تردد أحياناً'، 'ينقصها الابتسامة وبها تردد'، 'ينقصها التفاعل'، 'ينقصها الحماس')، وتجنب أي صياغة أخرى للعيوب.",
                  items: { type: Type.STRING },
                },
                score: {
                  type: Type.INTEGER,
                  description: "تقييم إجمالي لنبرة الصوت مجملاً من 10",
                },
              },
              required: ["introductionSummary", "callSummary", "hasSmile", "smileEvaluation", "detectedTraits", "score"],
            },
            isBenchmark: {
              type: Type.BOOLEAN,
              description: "هل تُعد هذه المكالمة معياراً مرجعياً قياسياً (Benchmark Call) أم مكالمة اعتيادية",
            },
            benchmarkNotes: {
              type: Type.STRING,
              description: "ملاحظات المعايرة القياسية للمكالمة المرجعية",
            },
            verbalTicsAnalysis: {
              type: Type.OBJECT,
              description: "تحليل وتتبع اللازمات اللفظية والكلمات المكررة بصورة مفرطة ومستمرة من قبل الزميل تفادياً لإعياء العميل.",
              properties: {
                hasVerbalTics: {
                  type: Type.BOOLEAN,
                  description: "هل رُصد لدى الزميل أي لازمة لفظية مكررة بشكل متكرر (مثلاً تكرار كلمة لـ 3 مرات أو أكثر)؟",
                },
                detectedTics: {
                  type: Type.ARRAY,
                  description: "قائمة باللازمات اللفظية المكررة المكتشفة من كلام الزميل فقط.",
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      word: { type: Type.STRING, description: "الكلمة أو العبارة المتكررة كلازمة لفظية" },
                      count: { type: Type.INTEGER, description: "عدد مرات التكرار" },
                      timestamps: {
                        type: Type.ARRAY,
                        description: "الطوابع الزمنية للتكرارات بصيغة MM:SS",
                        items: { type: Type.STRING },
                      },
                    },
                    required: ["word", "count", "timestamps"],
                  },
                },
                evaluation: {
                  type: Type.STRING,
                  description: "التقييم الفني بالعامية المصرية بخصوص اللازمات اللفظية الملتقطة للزميل وتوضيح سبل تجنب الرتابة اللفظية.",
                },
              },
              required: ["hasVerbalTics", "detectedTics", "evaluation"],
            },
          },
          required: [
            "transcript",
            "agentSilenceSummary",
            "customerNameAnalysis",
            "customerTitleAnalysis",
            "holdTimeSummary",
            "greetingAnalysis",
            "empathyAnalysis",
            "furtherAssistanceAnalysis",
            "unprofessionalWordsAnalysis",
            "callEndingAnalysis",
            "agentApologyAnalysis",
            "agentToneAnalysis",
            "verbalTicsAnalysis",
          ],
        },
      },
    });

    const responseText = response.text;
    if (!responseText) {
      throw new Error("استجابة فارغة من خادم الذكاء الاصطناعي.");
    }

    const parsedData = JSON.parse(responseText.trim());
    parsedData._engineInfo = {
      whisperApiUsed: isWhisperApiUsed,
      qwenCleoUsed: isQwenCleoUsed,
      engineName: isQwenCleoUsed && isWhisperApiUsed
        ? "مكتبة QwenCleo-ASR (العامية المصرية) + OpenAI Whisper + Gemini Acoustic Diarization"
        : isQwenCleoUsed
        ? "مكتبة QwenCleo-ASR (العامية المصرية) + Gemini Acoustic Diarization"
        : isWhisperApiUsed
        ? "مكتبة Whisper (OpenAI whisper-1) + Gemini Acoustic Diarization"
        : "محرك المعالجة الصوتية فائق الدقة (Whisper-Grade Acoustic Precision)",
      faintAudioCaptured: true,
      speakerDiarizationEnabled: true,
    };
    res.json(parsedData);
  } catch (error: any) {
    console.error("Transcription error:", error);
    res.status(500).json({
      error: "حدث خطأ أثناء معالجة وتسجيل تفريغ المحادثة: " + (error?.message || "خطأ غير معروف"),
    });
  }
});

// Final API error handler (including multer upload errors).
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (err?.code === "LIMIT_FILE_SIZE") {
    return res.status(413).json({
      error: `حجم الملف أكبر من الحد المسموح (${process.env.MAX_AUDIO_MB || 25} MB).`,
    });
  }
  console.error("Unhandled server error:", err);
  if (!res.headersSent) {
    return res.status(err?.status || 500).json({
      error: "حدث خطأ غير متوقع في الخادم.",
    });
  }
  next(err);
});

// Vite server integrations
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server is running at http://0.0.0.0:${PORT}`);
  });
  // Extend HTTP timeout to 5 minutes for audio processing
  server.setTimeout(300000);
  server.keepAliveTimeout = 300000;
  server.headersTimeout = 305000;
}

startServer();
